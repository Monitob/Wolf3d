/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_moove_file.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/18 20:50:10 by obengelo          #+#    #+#             */
/*   Updated: 2014/01/18 22:40:54 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

static t_env	*ft_up_press(t_env *e)
{
	if (e->map[(int)(e->o[0] + e->dir[0] * e->move_speed)][(int)(e->o[1])]
		== 48)
		e->o[0] += e->dir[0] * e->move_speed;
	if (e->map[(int)(e->o[0])][(int)(e->o[1] + e->dir[1] * e->move_speed)]
		== 48)
		e->o[1] += e->dir[1] * e->move_speed;
	return (e);
}

static t_env	*ft_down_press(t_env *e)
{
	if (e->map[(int)(e->o[0] - e->dir[0] * e->move_speed)][(int)(e->o[1])]
		== 48)
		e->o[0] -= e->dir[0] * e->move_speed;
	if (e->map[(int)(e->o[0])][(int)(e->o[1] - e->dir[1] * e->move_speed)]
		== 48)
		e->o[1] -= e->dir[1] * e->move_speed;
	return (e);
}

static t_env	*ft_right_press(t_env *e)
{
	e->old_dir = e->dir[0];
	e->dir[0] = e->dir[0] * cos(-e->rot_speed) - e->dir[1]
		* sin(-e->rot_speed);
	e->dir[1] = e->old_dir * sin(-e->rot_speed) + e->dir[1]
		* cos(-e->rot_speed);
	e->old_plane = e->plane[0];
	e->plane[0] = e->plane[0] * cos(-e->rot_speed) - e->plane[1]
		* sin(-e->rot_speed);
	e->plane[1] = e->old_plane * sin(-e->rot_speed) + e->plane[1]
		* cos(-e->rot_speed);
	return (e);
}

static t_env	*ft_left_press(t_env *e)
{
	e->old_dir = e->dir[0];
	e->dir[0] = e->dir[0] * cos(e->rot_speed) - e->dir[1]
		* sin(e->rot_speed);
	e->dir[1] = e->old_dir * sin(e->rot_speed) + e->dir[1]
		* cos(e->rot_speed);
	e->old_plane = e->plane[0];
	e->plane[0] = e->plane[0] * cos(e->rot_speed) - e->plane[1]
		* sin(e->rot_speed);
	e->plane[1] = e->old_plane * sin(e->rot_speed) + e->plane[1]
		* cos(e->rot_speed);
	return (e);
}

t_env			*ft_key_press(t_env *e, int keycode)
{
	if (keycode == UP)
	{
		e = ft_up_press(e);
		mlx_clear_window(e->mlx, e->win);
		draw(e);
	}
	if (keycode == DOWN)
	{
		e = ft_down_press(e);
		mlx_clear_window(e->mlx, e->win);
		draw(e);
	}
	if (keycode == LEFT)
	{
		e = ft_left_press(e);
		mlx_clear_window(e->mlx, e->win);
		draw(e);
	}
	if (keycode == RIGHT)
	{
		e = ft_right_press(e);
		mlx_clear_window(e->mlx, e->win);
		draw(e);
	}
	return (e);
}
