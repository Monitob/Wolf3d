/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_initialize_env.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/18 22:17:28 by obengelo          #+#    #+#             */
/*   Updated: 2014/01/18 23:42:09 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

t_env		*ft_get_env_var(t_env *e)
{
	e->o[0] = 5;
	e->o[1] = 5;
	e->dir[0] = -1;
	e->dir[1] = 0;
	e->l = 512;
	e->h = 384;
	e->map_h = 10;
	e->plane[0] = 0;
	e->plane[1] = 0.66;
	e->move_speed = 0.2;
	e->rot_speed = 0.1;
	return (e);
}

t_env		*ft_initialize(void)
{
	t_env	*e;

	e = (t_env *)malloc(sizeof(t_env));
	if (e == NULL)
	{
		perror("malloc");
		exit(-1);
	}
	e = ft_get_env_var(e);
	e->map = ft_fill_map(e);
	e->mlx = mlx_init();
	e->win = mlx_new_window(e->mlx, e->l, e->h, "WOLF3D");
	return (e);
}

int			key_hook(int keycode, t_env *e)
{
	e = ft_key_press(e, keycode);
	if (keycode == 65307)
		exit(0);
	return (0);
}

void		draw(t_env *e)
{
	int		x;
	int		color;

	x = 0;
	while (x < e->l)
	{
		e = ft_init_pos(e, x);
		e = ft_get_dist(e);
		e = ft_detect_wall(e);
		e = ft_get_wall_length(e);
		e->h_mur = fabs((int)(e->h / e->wall_length));
		e->draw_start = -e->h_mur / 2 + e->h / 2;
		if (e->draw_start < 0)
			e->draw_start = 0;
		e->draw_end = e->h_mur / 2 + e->h / 2;
		if (e->draw_end >= e->h)
			e->draw_end = e->h - 1;
		color = ft_color_card(e);
		if (e->murvoh == 1)
			color /= 2;
		draw_line(x, e, color);
		x++;
	}
}

int			expose_hook(t_env *e)
{
	draw(e);
	return (0);
}
