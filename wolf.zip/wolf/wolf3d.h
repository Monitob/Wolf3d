/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   wolf3d.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/18 22:33:27 by obengelo          #+#    #+#             */
/*   Updated: 2014/01/18 23:41:26 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WOLF3D_H
# define WOLF3D_H

# include <fcntl.h>
# include <sys/types.h>
# include <sys/uio.h>
# include <unistd.h>
# include <stdio.h>
# include <mlx.h>
# include <math.h>
# include "libft/includes/libft.h"

# define UP 65362
# define DOWN 65364
# define RIGHT 65363
# define LEFT 65361

typedef struct			s_env
{
	void				*mlx;
	void				*win;
	int					**map;
	int					l;
	int					h;
	double				o[2];
	double				dir[2];
	double				plane[2];
	double				camera;
	double				ray_o[2];
	double				ray_dir[2];
	int					mapx[2];
	double				dist_mur[2];
	double				dist_2_mur[2];
	double				wall_length;
	int					step[2];
	int					murvoh;
	int					touch;
	int					h_mur;
	int					draw_start;
	int					draw_end;
	int					map_h;
	int					fd;
	double				move_speed;
	double				rot_speed;
	double				old_dir;
	double				old_plane;
}						t_env;

t_env		*ft_initialize(void);
int			key_hook(int keycode, t_env *e);
int			expose_hook(t_env *e);
int			**ft_fill_map(t_env *e);
void		draw_line(int x, t_env *e, int color);
t_env		*ft_init_pos(t_env *e, int x);
t_env		*ft_get_dist(t_env *e);
t_env		*ft_detect_wall(t_env *e);
t_env		*ft_get_wall_length(t_env *e);
t_env		*ft_key_press(t_env *e, int keycode);
void		draw(t_env *e);
int			ft_color_card(t_env *e);

#endif
