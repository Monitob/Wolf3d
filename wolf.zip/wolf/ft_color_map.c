/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_color_map.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/18 22:10:45 by obengelo          #+#    #+#             */
/*   Updated: 2014/01/18 23:46:19 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

void		draw_line(int x, t_env *e, int color)
{
	int		y;

	y = 0;
	while (y < e->draw_start)
	{
		mlx_pixel_put(e->mlx, e->win, x, y, 0x77B5FE);
		y++;
	}
	while (y < e->draw_end)
	{
		mlx_pixel_put(e->mlx, e->win, x, y, color);
		y++;
	}
	while (y < e->h)
	{
		mlx_pixel_put(e->mlx, e->win, x, y, 0x808080);
		y++;
	}
}

int			ft_color_card(t_env *e)
{
	int		color;

	if (e->mapx[0] < 5 && e->mapx[1] < 5)
		color = 0x37FDFC;
	else if (e->mapx[0] < 5 && e->mapx[1] > 5)
		color = 0x22780F;
	else if (e->mapx[0] > 5 && e->mapx[1] < 5)
		color = 0xFFFF6B;
	else if (e->mapx[0] > 5 && e->mapx[1] > 5)
		color = 0xFF7F00;
	else if (e->mapx[0] == 5 && e->mapx[1] == 0)
		color = 0x00FF00;
	else if (e->mapx[0] == 5 && e->mapx[1] == 10)
		color = 0xFFFF00;
	else if (e->mapx[0] == 10 && e->mapx[1] == 5)
		color = 0xFF0000;
	else if (e->mapx[0] == 0 && e->mapx[1] == 5)
		color = 0x00FF00;
	return (color);
}
