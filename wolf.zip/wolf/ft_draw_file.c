/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_draw_file.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/18 20:00:01 by obengelo          #+#    #+#             */
/*   Updated: 2014/01/18 22:12:57 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

t_env		*ft_get_wall_length(t_env *e)
{
	if (e->murvoh == 0)
	{
		e->wall_length = fabs((e->mapx[0] - e->ray_o[0] + (1 - e->step[0]) / 2)
							/ e->ray_dir[0]);
	}
	else
	{
		e->wall_length = fabs((e->mapx[1] - e->ray_o[1] + (1 - e->step[1]) / 2)
							/ e->ray_dir[1]);
	}
	return (e);
}

t_env		*ft_detect_wall(t_env *e)
{
	while (e->touch == 0)
	{
		if (e->dist_mur[0] < e->dist_mur[1])
		{
			e->dist_mur[0] += e->dist_2_mur[0];
			e->mapx[0] += e->step[0];
			e->murvoh = 0;
		}
		else
		{
			e->dist_mur[1] += e->dist_2_mur[1];
			e->mapx[1] += e->step[1];
			e->murvoh = 1;
		}
		if ((e->map[e->mapx[0]][e->mapx[1]]) > 48)
			e->touch = 1;
	}
	return (e);
}

t_env		*ft_get_dist(t_env *e)
{
	if (e->ray_dir[0] < 0)
	{
		e->step[0] = -1;
		e->dist_mur[0] = (e->ray_o[0] - e->mapx[0]) * e->dist_2_mur[0];
	}
	else
	{
		e->step[0] = 1;
		e->dist_mur[0] = (e->mapx[0] + 1.0 - e->ray_o[0]) * e->dist_2_mur[0];
	}
	if (e->ray_dir[1] < 0)
	{
		e->step[1] = -1;
		e->dist_mur[1] = (e->ray_o[1] - e->mapx[1]) * e->dist_2_mur[1];
	}
	else
	{
		e->step[1] = 1;
		e->dist_mur[1] = (e->mapx[1] + 1.0 - e->ray_o[1]) * e->dist_2_mur[1];
	}
	return (e);
}

t_env		*ft_init_pos(t_env *e, int x)
{
	e->camera = 2 * x / (double)(e->l) - 1;
	e->ray_o[0] = e->o[0];
	e->ray_o[1] = e->o[1];
	e->ray_dir[0] = e->dir[0] + e->plane[0] * e->camera;
	e->ray_dir[1] = e->dir[1] + e->plane[1] * e->camera;
	e->mapx[0] = (int)(e->ray_o[0]);
	e->mapx[1] = (int)(e->ray_o[1]);
	e->dist_2_mur[0] = sqrt(1 + (e->ray_dir[1] * e->ray_dir[1])
							/ (e->ray_dir[0] * e->ray_dir[0]));
	e->dist_2_mur[1] = sqrt(1 + (e->ray_dir[0] * e->ray_dir[0])
							/ (e->ray_dir[1] * e->ray_dir[1]));
	e->touch = 0;
	return (e);
}
