/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_map.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/17 22:47:13 by obengelo          #+#    #+#             */
/*   Updated: 2014/01/18 22:46:38 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "wolf3d.h"

static int			ft_check_fd(void)
{
	int				fd;

	fd = open("map", O_RDONLY);
	if (fd == -1)
	{
		perror("close");
		exit(-1);
	}
	return (fd);
}

static void			ft_check_error(int **map)
{
	if (map == NULL)
	{
		perror("first D malloc");
		exit(-1);
	}
}

static int			**ft_realloc(char *line, int **map, int pos)
{
	int				j;
	int				size;

	j = 0;
	size = ft_strlen(line);
	map[pos] = (int *)malloc(sizeof(int) * size);
	if (map[pos] == NULL)
	{
		perror("map malloc");
		exit(-1);
	}
	while (j < size)
	{
		map[pos][j] = line[j] + 0;
		j++;
	}
	return (map);
}

int					**ft_fill_map(t_env *e)
{
	char			*line;
	int				**map;
	int				ret;
	int				pos;

	ret = 1;
	map = NULL;
	pos = 0;
	e->fd = ft_check_fd();
	map = (int **)malloc(sizeof(int *) * e->map_h);
	ft_check_error(map);
	while (ret != 0 && ret != -1)
	{
		ret = get_next_line(e->fd, &line);
		map = ft_realloc(line, map, pos);
		pos++;
		free(line);
	}
	if (ret == -1)
	{
		perror("read");
		exit(-1);
	}
	return (map);
}
