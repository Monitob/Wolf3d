/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/21 18:26:11 by obengelo          #+#    #+#             */
/*   Updated: 2014/01/18 22:48:41 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

void					*ft_memccpy(void *s1, const void *s2, int c, size_t n)
{
	unsigned char		*s1_bis;
	unsigned const char	*s2_bis;

	s1_bis = s1;
	s2_bis = s2;
	while (n > 0)
	{
		*s1_bis = *s2_bis;
		s1_bis++;
		if (*s2_bis == (unsigned char)c)
			return ((void *)(s1_bis));
		s2_bis++;
		n--;
	}
	return (NULL);
}

