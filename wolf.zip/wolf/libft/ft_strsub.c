/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsub.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/24 18:57:24 by obengelo          #+#    #+#             */
/*   Updated: 2013/11/25 15:54:56 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

char	*ft_strsub(char const *s, unsigned int start, size_t len)
{
	char	*string;
	size_t	index;

	index = 0;
	if (s != NULL)
	{
		string = ft_strnew(len);
		if (string == NULL)
			return (string);
		while (len > 0)
		{
			string[index] = s[start];
			start++;
			index++;
			len--;
		}
		return (string);
	}
	return (NULL);
}
