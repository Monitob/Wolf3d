/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 16:32:07 by obengelo          #+#    #+#             */
/*   Updated: 2013/12/01 19:44:05 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

char	*ft_strrchr(const char *s, int c)
{
	int		i;
	int		j;

	j = -1;
	i = 0;
	while (s[i])
	{
		if (s[i] == (char)c)
		{
			j = i;
		}
		i++;
	}
	if (s[i] == (char)c && (char)c == '\0')
		return ((char *)&s[i]);
	else if (j >= 0)
		return ((char *)&s[j]);
	return (NULL);
}
