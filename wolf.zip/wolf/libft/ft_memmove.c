/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/21 19:11:03 by obengelo          #+#    #+#             */
/*   Updated: 2014/01/12 17:04:57 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

void					*ft_memmove(void *s1, const void *s2, size_t n)
{
	unsigned char		*s1_bis;
	unsigned const char	*s2_bis;

	s1_bis = s1;
	s2_bis = s2;
	if (s1_bis < s2_bis || s1_bis > (s2_bis + n))
	{
			s1 = ft_memcpy(s1, s2, n);
	}
	else
	{
		while (n > 0)
		{
			s1_bis[n - 1] = s2_bis[n - 1];
			n--;
		}
	}
		return (s1);
}
