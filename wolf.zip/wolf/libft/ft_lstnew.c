/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstnew.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/29 15:03:13 by obengelo          #+#    #+#             */
/*   Updated: 2014/01/10 21:23:37 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

t_list	*ft_lstnew(void const *content, size_t content_size)
{
	t_list	*L;

	L = (t_list *)malloc(sizeof(t_list));
	if (L == NULL)
		return (NULL);
	if (content == NULL)
	{
		L->content = NULL;
		L->content_size = 0;
	}
	else
	{
		L->content = ft_memalloc(content_size);
		if (L->content == NULL)
			return (NULL);
		ft_memcpy(L->content, content, content_size);
		L->content_size = content_size;
	}
	L->cursor = 0;
	L->underlined = 0;
	L->next = NULL;
	return (L);
}
