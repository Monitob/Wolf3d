/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strequ.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/19 16:02:14 by obengelo          #+#    #+#             */
/*   Updated: 2013/12/11 12:58:14 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

int	ft_strequ(char const *s1, char const *s2)
{
	int		value;

	value = 1;
	if (s1 != NULL && s2 != NULL)
		value = ft_strcmp(s1, s2);
	if (value == 0)
		return (1);
	return (0);
}
