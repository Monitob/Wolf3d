/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 17:26:32 by obengelo          #+#    #+#             */
/*   Updated: 2013/12/01 22:34:11 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

void	*ft_memset(void *b, int c, size_t len)
{
	unsigned char	*bis;

	bis = b;
	while (len > 0)
	{
		*bis = (unsigned char)c;
		bis++;
		len--;
	}
	return (b);
}
