/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/19 18:44:44 by obengelo          #+#    #+#             */
/*   Updated: 2013/12/08 20:12:57 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

int	ft_atoi(const char *str)
{
	int	symbol;
	int	result;

	result = 0;
	symbol = 1;
	while (*str == '\t' || *str == '\n' || *str == ' ' || *str == '\v'
			|| *str == '\r' || *str == '\f')
		str++;
	if (*str == '-')
		symbol = -1;
	if (symbol == -1 || *str == '+')
		str++;
	while (ft_isdigit(*str))
	{
		result = result * 10;
		result = result + *str - '0';
		str++;
	}
	return (symbol * result);
}
