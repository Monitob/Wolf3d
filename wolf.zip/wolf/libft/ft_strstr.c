/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/19 18:43:50 by obengelo          #+#    #+#             */
/*   Updated: 2013/12/08 19:13:32 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

char	*ft_strstr(const char *s1, const char *s2)
{
	if (ft_strlen(s2) == 0)
		return ((char *)(s1));
	while (*s1)
	{
		if (*s1 == *s2)
		{
			if (!ft_strncmp(s1, s2, ft_strlen(s2)))
				return ((char *)(s1));
		}
		s1++;
	}
	return (NULL);
}
