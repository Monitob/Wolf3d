/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstdel.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/29 16:12:50 by obengelo          #+#    #+#             */
/*   Updated: 2013/11/29 17:56:43 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

void	ft_lstdel(t_list **alst, void (*del)(void *, size_t))
{
	t_list	*L;
	t_list	*p;

	if (alst != NULL)
	{
		L = *alst;
		while (L != NULL)
		{
			p = L;
			L = L->next;
			ft_lstdelone(&p, del);
		}
		*alst = NULL;
	}
}
