/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/21 18:14:18 by obengelo          #+#    #+#             */
/*   Updated: 2014/01/12 17:04:16 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

void			*ft_memcpy(void *s1, const void *s2, size_t n)
{
	char		*s1_bis;
	const char	*s2_bis;

	s1_bis = s1;
	s2_bis = s2;
	while (n > 0)
	{
		*s1_bis = *s2_bis;
		s1_bis++;
		s2_bis++;
		n--;
	}
	return (s1);
}
