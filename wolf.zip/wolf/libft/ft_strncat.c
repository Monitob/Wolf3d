/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 15:29:16 by obengelo          #+#    #+#             */
/*   Updated: 2013/12/05 19:32:57 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

char	*ft_strncat(char *s1, const char *s2, size_t n)
{
	char	*p;
	char	*t;

	t = (char *)s2;
	p = s1;
	while (*p)
		p++;
	while (n > 0 && *t)
	{
		*p = *t;
		p++;
		t++;
		n--;
	}
	*p = '\0';
	return (s1);
}
