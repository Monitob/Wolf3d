/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 15:45:15 by obengelo          #+#    #+#             */
/*   Updated: 2013/12/01 17:54:48 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	size_t	size_dst;
	size_t	counter;

	counter = 0;
	if (size == 0)
		return (ft_strlen(src));
	size_dst = ft_strlen(dst);
	if (size_dst > size)
		return (size + ft_strlen(src));
	while (src[counter] && (counter + size_dst) < (size - 1))
	{
		dst[size_dst + counter] = src[counter];
		counter++;
	}
	dst[size_dst + counter] = '\0';
	return (size_dst + ft_strlen(src));
}
