/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnequ.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/19 16:32:33 by obengelo          #+#    #+#             */
/*   Updated: 2013/12/11 12:58:01 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

int	ft_strnequ(char const *s1, char const *s2, size_t n)
{
	size_t	value;

	value = 1;
	if (s1 != NULL && s2 != NULL)
		value = ft_strncmp(s1, s2, n);
	if (value == 0)
		return (1);
	else
		return (0);
}

