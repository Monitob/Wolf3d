/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/21 20:43:41 by obengelo          #+#    #+#             */
/*   Updated: 2013/12/01 19:45:57 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

void	*ft_memchr(const void *s, int c, size_t n)
{
	unsigned const char	*tmp;

	tmp = s;
	while (n > 0)
	{
		if (*tmp != (unsigned char)c)
			tmp++;
		else
			return ((void *)(tmp));
		n--;
	}
	return (NULL);
}
