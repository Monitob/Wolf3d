/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/25 14:11:54 by obengelo          #+#    #+#             */
/*   Updated: 2013/12/01 20:55:35 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	char	*string;
	size_t	index;

	index = 0;
	if (s != NULL && f != NULL)
	{
		string = ft_strnew(ft_strlen(s));
		if (string == NULL)
			return (NULL);
		while (s[index])
		{
			string[index] = f(index, s[index]);
			index++;
		}
		return (string);
	}
	return (NULL);
}
