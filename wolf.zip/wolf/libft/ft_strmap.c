/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/23 16:15:25 by obengelo          #+#    #+#             */
/*   Updated: 2013/12/02 17:12:38 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

char	*ft_strmap(char const *s, char (*f)(char))
{
	char	*string;
	char	*p;

	if (s != NULL && f != NULL)
	{
		string = ft_strnew(ft_strlen(s));
		if (string != NULL)
		{
			p = string;
			while (*s)
			{
				*string = f(*s);
				s++;
				string++;
			}
			return (p);
		}
	}
	return (NULL);
}
