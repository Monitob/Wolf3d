/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obengelo <obengelo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/19 18:43:15 by obengelo          #+#    #+#             */
/*   Updated: 2013/12/05 18:40:41 by obengelo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "includes/libft.h"

char	*ft_strncpy(char *s1, const char *s2, size_t n)
{
	char	*p;
	size_t	index;

	index = 0;
	p = s1;
	while (n > 0 && s2[index])
	{
		*p = s2[index];
		p++;
		index++;
		n--;
	}
	while (n > 0)
	{
		*p = '\0';
		p++;
		n--;
	}
	return (s1);
}
