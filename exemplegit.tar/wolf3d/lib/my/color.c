/*
** color.c for color in /home/ninon_s//printf
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Thu Nov 15 15:51:02 2012 simon ninon
** Last update Fri Jan 11 15:35:51 2013 simon ninon
*/

#include <stdarg.h>
#include "my_printf.h"
#include "my.h"

int	check_color_flag(const char *str)
{
  int	i;

  i = 0;
  if (!(str[i++] == 'C'))
    return (0);
  if (!(str[i++] == 'O'))
    return (0);
  if (!(str[i++] == 'L'))
    return (0);
  if (!(str[i++] == 'O'))
    return (0);
  if (!(str[i++] == 'R'))
    return (0);
  return (1);
}

void	put_color(char *color)
{
  if (my_strcmp(color, "RED") == 0)
    my_putstr(RED);
  else if (my_strcmp(color, "BLUE") == 0)
    my_putstr(BLUE);
  else if (my_strcmp(color, "YELLOW") == 0)
    my_putstr(YELLOW);
  else if (my_strcmp(color, "CYAN") == 0)
    my_putstr(CYAN);
  else if (my_strcmp(color, "BLACK") == 0)
    my_putstr(BLACK);
  else if (my_strcmp(color, "GREY") == 0)
    my_putstr(GREY);
  else if (my_strcmp(color, "PURPLE") == 0)
    my_putstr(PURPLE);
  else if (my_strcmp(color, "GREEN") == 0)
    my_putstr(GREEN);
  else if (my_strcmp(color, "WHITE") == 0)
    my_putstr(WHITE);
}

int	check_color(const char *str, va_list ap)
{
  char	*color;

  if (!check_color_flag(str))
    return (0);
  color = va_arg(ap, char*);
  put_color(color);
  return (4);
}
