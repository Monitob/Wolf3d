/*
** my_strcat.c for my_strcat in /home/ninon_s//Makefile/lib/my
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Sun Dec 30 19:04:32 2012 simon ninon
** Last update Thu Jan  3 20:10:48 2013 simon ninon
*/

#include "my.h"
#include <stdlib.h>

char	*my_strcat(char *str1, char *str2)
{
  int	i;
  int	j;
  char	*new_str;

  i = 0;
  j = 0;
  new_str = malloc(my_strlen(str1) + my_strlen(str2) + 1);
  if (new_str == NULL)
    return (NULL);
  while (str1[i])
    {
      new_str[i] = str1[i];
      i++;
    }
  while (str2[j])
    new_str[i++] = str2[j++];
  new_str[i] = '\0';
  return (new_str);
}
