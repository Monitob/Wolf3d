/*
** gimme_nbr.c for gimme_nbr in /home/ninon_s//printf
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Thu Nov 15 19:45:11 2012 simon ninon
** Last update Thu Jan  3 20:09:36 2013 simon ninon
*/

#include "my_printf.h"
#include "my.h"

int	gimme_size_nbr(int nbr)
{
  int	i;

  i = 1;
  if (nbr < 0)
    i = 2;
  while (nbr > 9 || nbr < -9)
    {
      nbr = nbr / 10;
      i = i + 1;
    }
  return (i);
}

int	gimme_unsigned_size(unsigned int nbr)
{
  int	i;

  i = 1;
  while (nbr > 9)
    {
      nbr = nbr / 10;
      i = i + 1;
    }
  return (i);
}
