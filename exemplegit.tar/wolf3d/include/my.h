/*
** my.h for my.h in /home/ninon_s/
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Thu Oct 11 23:20:15 2012 simon ninon
** Last update Sun Dec 30 19:09:31 2012 simon ninon
*/

#ifndef MY_H_
# define MY_H_

int	my_getnbr(char *);
void	my_putchar(char);
void	my_put_nbr(int);
void	my_putstr(char *);
int	my_strcmp(char *, char *);
int	my_strlen(char *);
char	*my_strcat(char *, char*);

#endif /* !MY_H_ */
