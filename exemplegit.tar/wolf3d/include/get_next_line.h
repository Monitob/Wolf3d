/*
** get_next_line.h for get_next_line.h in /home/ninon_s//GNL
** 
** Made by simon ninon
** Login   <ninon_s@epitech.net>
** 
** Started on  Tue Nov 20 14:37:20 2012 simon ninon
** Last update Sat Nov 24 17:29:53 2012 simon ninon
*/

#ifndef GET_NEXT_LINE_H_
# define GET_NEXT_LINE_H_

# define MAX_READ 10

int	my_strlen(char *str);
char	*my_strcat(char *file_buffer, char *buffer);
char	*gimme_good_line(char *file_buffer);
int	check_buffer(char *file_buffer);
char	*get_next_line(const int fd);

#endif /* !GET_NEXT_LINE_H_ */
