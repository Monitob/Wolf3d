/*
** minecraft.c for minecraft in /home/ninon_s//Dropbox/Epitech/current/wolf3D/src
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Fri Jan 11 00:10:20 2013 simon ninon
** Last update Fri Jan 11 20:38:37 2013 simon ninon
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <math.h>
#include "my.h"
#include "mlx.h"
#include "wolf.h"

void	add_block(t_data *data)
{
  float	case_x;
  float	case_y;
  float	new_x;
  float	new_y;
  float	angle;

  case_x = CASE_SIZE_X(data->file->size_line);
  case_y = CASE_SIZE_Y(data->file->nbr_lines);
  angle = RADIAN(data->perso->angle);
  new_x = cos(angle) * case_x;
  new_y = sin(angle) * case_y;
  if (data->perso->x + new_x > 0
      && data->perso->y - new_y > 0
      && data->perso->x + new_x < IMG_SIZE_X
      && data->perso->y - new_y < IMG_SIZE_Y
      && data->file->map[(int)((data->perso->y - new_y) / case_y)]
      [(int)((data->perso->x + new_x) / case_x)] == 0)
    {
      data->file->map[(int)((data->perso->y - new_y) / case_y)]
	[(int)((data->perso->x + new_x) / case_x)] = 1;
    }
}

void	remove_block(t_data *data)
{
  float	case_x;
  float	case_y;
  float	new_x;
  float	new_y;
  float	angle;

  case_x = CASE_SIZE_X(data->file->size_line);
  case_y = CASE_SIZE_Y(data->file->nbr_lines);
  angle = RADIAN(data->perso->angle);
  new_x = cos(angle) * case_x;
  new_y = sin(angle) * case_y;
  if (data->perso->x + new_x > case_x
      && data->perso->y - new_y > case_y
      && data->perso->x + new_x < IMG_SIZE_X - case_x
      && data->perso->y - new_y < IMG_SIZE_Y - case_y
      && data->file->map[(int)((data->perso->y - new_y) / case_y)]
      [(int)((data->perso->x + new_x) / case_x)] == 1)
    {
      data->file->map[(int)((data->perso->y - new_y) / case_y)]
	[(int)((data->perso->x + new_x) / case_x)] = 0;
    }
}

void	save(t_data *data)
{
  int	i;
  int	j;
  int	fd;
  char	c;

  i = -1;
  if ((open("save_map", O_CREAT, 00666) == -1)
      || (fd = open("save_map", O_WRONLY)) == -1)
    {
      my_printf("%COLOR[Error] %COLORError while saving!\n", "RED", "WHITE");
      return ;
    }
  while (++i < data->file->nbr_lines)
    {
      j = -1;
      while (++j < data->file->size_line)
	{
	  c = data->file->map[i][j] + '0';
	  write(fd, &c, 1);
	  if (j + 1 == data->file->size_line)
	    write(fd, "\n", 1);
	  else
	    write(fd, " ", 1);
	}
    }
}
