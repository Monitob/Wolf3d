/*
** draw.c for draw in /home/ninon_s//fdf
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Wed Dec  5 17:14:04 2012 simon ninon
** Last update Thu Jan 10 01:48:40 2013 simon ninon
*/

#include "mlx.h"
#include "wolf.h"

void	my_pixel_put_to_image(t_img *img, t_win *win, t_draw *draw)
{
  int	i;
  int	x;
  int	y;

  i = 0;
  x = (int)draw->x * img->bpp / 8;
  y = (int)draw->y * img->size_line;
  img->data[x + i++ + y] = mlx_get_color_value(win->mlx_ptr, draw->blue);
  img->data[x + i++ + y] = mlx_get_color_value(win->mlx_ptr, draw->green);
  img->data[x + i++ + y] = mlx_get_color_value(win->mlx_ptr, draw->red);
}
