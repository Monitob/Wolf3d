/*
** hook.c for hook in /home/ninon_s//Dropbox/Epitech/current/new_wolf3D/src
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Mon Dec 31 19:07:45 2012 simon ninon
** Last update Fri Jan 11 18:34:02 2013 simon ninon
*/

#include <stdlib.h>
#include "my_printf.h"
#include "wolf.h"
#include "mlx.h"
#include "my.h"

int	check_expose_hook(t_data *data)
{
  mlx_put_image_to_window(data->win->mlx_ptr,
			  data->win->win_ptr,
			  data->img->img_ptr,
			  IMG_POS_X,
			  IMG_POS_Y);
  text(data);
  return (0);
}

void	free_all(t_data *data)
{
  int	i;

  i = 0;
  while (i < data->file->nbr_lines)
    free(data->file->map[i++]);
  free(data->file->map[i]);
  free(data->file);
  free(data->win);
  free(data->img);
  free(data->background);
  free(data->floor);
  free(data->draw);
  free(data->perso);
  free(data);
}

void	check_actions(t_data *data, int key)
{
  if (key == MINIMAP)
    data->draw->minimap *= -1;
  else if (key == PLUS && data->perso->precision > 0.01)
    data->perso->precision /= 2;
  else if (key == MINUS && data->perso->precision < 10)
    data->perso->precision *= 2;
  else if (key == ENTER)
    add_block(data);
  else if (key == SPACE)
    remove_block(data);
  else if (key == SAVE)
    save(data);
  else if (key == RUN && data->perso->speed == 15)
    data->perso->speed = 5;
  else if (key == RUN && data->perso->speed == 5)
    data->perso->speed = 15;
  else
    return ;
  lets_draw(data);
}

int	check_key_hook(int key, t_data *data)
{
  if (key == ESC)
    {
      my_printf("%COLOR[Exit] %COLORHope to see you soon!\n", "RED", "WHITE");
      free_all(data);
      exit(1);
    }
  else if (key == LEFT)
    left(data);
  else if (key == UP)
    up(data);
  else if (key == RIGHT)
    right(data);
  else if (key == DOWN)
    down(data);
  else
    {
      check_actions(data, key);
      return (0);
    }
  lets_draw(data);
  return (0);
}
