/*
** background.c for background in /home/ninon_s//Dropbox/Epitech/current/wolf3D/src
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Thu Jan 10 18:03:32 2013 simon ninon
** Last update Sun Jan 13 21:13:15 2013 simon ninon
*/

#include "my.h"
#include "mlx.h"
#include "wolf.h"

void		put_background(t_data *data)
{
  data->draw->y = 0;
  while (data->draw->y < IMG_SIZE_Y)
    {
      if (data->draw->y < IMG_SIZE_Y / 2
	  && data->background->x == IMG_SIZE_X
	  && data->background->y == IMG_SIZE_Y / 2)
	cpy_img(data);
      else if (data->draw->y > IMG_SIZE_Y / 2
	       && data->floor->x == IMG_SIZE_X
	       && data->floor->y == IMG_SIZE_Y / 2)
	cpy_floor(data);
      data->draw->y++;
    }
}
