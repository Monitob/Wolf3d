/*
** color.c for color in /home/ninon_s//Dropbox/Epitech/current/wolf3D/src
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Tue Jan  8 16:44:06 2013 simon ninon
** Last update Fri Jan 11 16:34:44 2013 simon ninon
*/

#include "wolf.h"

void	color_one(t_data *data)
{
  data->draw->blue = 140;
  data->draw->red = 102;
  data->draw->green = 46;
}

void	color_two(t_data *data)
{
  data->draw->blue = 140;
  data->draw->red = 23;
  data->draw->green = 82;
}

void	color_three(t_data *data)
{
  data->draw->blue = 140;
  data->draw->red = 112;
  data->draw->green = 135;
}

void	color_four(t_data *data)
{
  data->draw->blue = 129;
  data->draw->red = 51;
  data->draw->green = 140;
}
