/*
** draw.c for draw.c in /home/ninon_s//Dropbox/Epitech/current/wolf3D/src
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Tue Jan  1 01:37:48 2013 simon ninon
** Last update Sun Jan 13 21:14:09 2013 simon ninon
*/

#include <math.h>
#include "mlx.h"
#include "wolf.h"

void		put_wall(t_data *data, double angle)
{
  float	dist;
  float	size;

  dist = pow(data->draw->x - data->perso->x, 2);
  dist += pow(data->draw->y - data->perso->y, 2);
  dist = sqrt(dist);
  size = IMG_SIZE_Y / dist * 25 / cos(RADIAN(data->perso->angle - angle));
  if (size > IMG_SIZE_Y - 1)
    size = IMG_SIZE_Y - 1;
  data->draw->x = angle - ANGLE_MIN(data->perso->angle) + 360;
  data->draw->x *= (IMG_SIZE_X / 60);
  data->draw->y = (IMG_SIZE_Y - size) / 2;
  while (data->draw->y < (IMG_SIZE_Y + size) / 2)
    {
      my_pixel_put_to_image(data->img, data->win, data->draw);
      data->draw->y++;
    }
}

void	find_intersection(t_data *data, int case_x, int case_y, float angle)
{
  while (data->draw->y >= 0
	 && data->draw->x >= 0
	 && data->draw->y < IMG_SIZE_Y
	 && data->draw->x < IMG_SIZE_X
	 && data->file->map[(int)data->draw->y / case_y]
	 [(int)data->draw->x / case_x] == 0)
    {
      data->draw->x += cos(RADIAN(angle)) * 2;
      data->draw->y -= sin(RADIAN(angle)) * 2;
    }
  while (data->draw->y >= 0
	 && data->draw->x >= 0
	 && data->draw->y < IMG_SIZE_Y
	 && data->draw->x < IMG_SIZE_X
	 && data->file->map[(int)data->draw->y / case_y]
	 [(int)data->draw->x / case_x])
    {
      data->draw->x -= cos(RADIAN(angle)) * data->perso->precision * 0.1;
      data->draw->y += sin(RADIAN(angle)) * data->perso->precision * 0.1;
    }
}

void	search_walls(t_data *data)
{
  int		case_x;
  int		case_y;
  float	angle;

  case_x = CASE_SIZE_X(data->file->size_line);
  case_y = CASE_SIZE_Y(data->file->nbr_lines);
  angle = ANGLE_MIN(data->perso->angle) + 360;
  while (angle < ANGLE_MAX(data->perso->angle) + 360)
    {
      data->draw->x = data->perso->x;
      data->draw->y = data->perso->y;
      find_intersection(data, case_x, case_y, angle);
      data->draw->x += cos(RADIAN(angle)) * data->perso->precision;
      data->draw->y -= sin(RADIAN(angle)) * data->perso->precision;
      gimme_color(data,
		  data->draw->x - cos(RADIAN(angle)) * data->perso->precision,
		  data->draw->y + sin(RADIAN(angle)) * data->perso->precision,
		  angle);
      put_wall(data, angle);
      angle += 0.1;
    }
}

void		lets_draw(t_data *data)
{
  put_background(data);
  search_walls(data);
  if (data->draw->minimap == 1)
    {
      put_minimap(data);
      put_angle(data);
    }
  if (data->gun->x == 450 && data->gun->y == 350)
    cpy_gun(data);
  mlx_put_image_to_window(data->win->mlx_ptr,
			  data->win->win_ptr,
			  data->img->img_ptr,
			  IMG_POS_X,
			  IMG_POS_Y);
}
