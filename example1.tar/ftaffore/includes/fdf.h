/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ftaffore <ftaffore@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/04 13:30:11 by ftaffore          #+#    #+#             */
/*   Updated: 2013/12/19 14:49:25 by ftaffore         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef		FDF_H
# define	FDF_H

#define		NORME(a, b)		(a >= b) ? (a - b) : (b - a)
#define		LOWER(a, b)		(a >= b) ? (b) : (a)
#define		ABS(a)			(a >= 0) ? (a) : (-a)
#define		MUL(a, b)		(a > b) ? (1) : (-1)
#define		INVERSE(a, b)	(a > b) ? (1.00 / (a - b)) : (1.00 / (b - a))
#define		WIN_SIZE		800
#define		CTE1			0.6
#define		CTE2			0.6
#define		COLOR			0xFF00FF

typedef	struct		s_info
{
	float			mul;
	float			inv;
	float			norme;
}					t_info;

typedef	struct		s_coor
{
	float			x_;
	float			y_;
	float			z_;
	struct s_coor	*next;
}					t_coor;

typedef	struct		s_map
{
	int				height_;
	int				length_;
	float			size_h_;
	float			size_l_;
	int				**map_;

	struct s_coor	*start_;
}					t_map;

typedef	struct		s_env
{
	void			*core_;
	void			*win_;
	void			*img_;
	char			*data_;
	unsigned long	color_;
	int				bpp_;
	int				sizeline_;
	int				endian_;
}					t_env;

t_map				*ft_fill_map(int fd, t_map *head);
t_map				*ft_fill_coor(t_map *head);
int					key_hook(int keycode, t_env *env);
int					expose_hook(t_env *env);
int					ft_display_map(t_map *head);
void				ft_draw_line(t_env *env, t_coor *p1, t_coor *p2);
void				ft_del_map(t_map **head);
void				ft_del_env(t_env **env);

#endif /* !FDF_H */
