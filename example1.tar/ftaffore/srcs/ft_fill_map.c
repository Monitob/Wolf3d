/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fill_map.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ftaffore <ftaffore@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/04 14:33:33 by ftaffore          #+#    #+#             */
/*   Updated: 2014/01/14 20:49:34 by jbernabe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<fcntl.h>
#include	"get_next_line.h"
#include	"libft.h"
#include	"fdf.h"

static int	**my_realloc_map(t_map *head, char **tab, int size)
{
	int		**res;
	int		i;
	int		j;

	i = 0;
	j = 0;
	if (tab == NULL || head->length_ != ft_tablen(tab))
		return (NULL);
	if ((res = (int **)ft_memalloc(sizeof(res) * (size + 1))) == NULL)
		return (0);
	while (i < size - 1)
	{
		if ((res[i] = (int *)ft_memalloc(head->length_ * sizeof(int))) == NULL)
			return (NULL);
		ft_memcpy(res[i], head->map_[i], (int)(head->length_ * sizeof(int)));
		i++;
	}
	if ((res[i] = (int *)ft_memalloc(head->length_ * sizeof(int))) == NULL)
		return (NULL);
	while (tab[j++] != NULL)
		res[i][j] = ft_atoi(tab[j]);
	ft_deltab(tab);
	ft_deltab_int(head->map_);
	return (res);
}

t_map		*ft_fill_map(int fd, t_map *head)
{
	char	*line;
	int		i;

	i = 1;
	if ((head = (t_map *)ft_memalloc(sizeof(*head))) == NULL)
		return (NULL);
	head->map_ = NULL;
	if (get_next_line(fd, &line) <= 0)
		return (NULL);
	head->length_ = ft_tablen(ft_strsplit(line, ' '));
	if ((head->map_ = my_realloc_map(head, ft_strsplit(line, ' '), i)) == NULL)
		return (NULL);
	while (get_next_line(fd, &line) > 0)
	{
		i++;
		head->height_ = i;
		head->map_ = my_realloc_map(head, ft_strsplit(line, ' '), i);
		if (head->map_ == NULL)
			return (NULL);
	}
	return (head);
}
