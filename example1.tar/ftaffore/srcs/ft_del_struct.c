/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_del_struct.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ftaffore <ftaffore@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/12 15:52:45 by ftaffore          #+#    #+#             */
/*   Updated: 2013/12/12 16:05:11 by ftaffore         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<stdlib.h>
#include	"libft.h"
#include	"fdf.h"

static void	ft_del_coor(t_coor *elem)
{
	if (elem != NULL)
	{
		ft_del_coor(elem->next);
		free(elem);
		elem = NULL;
	}
}

void		ft_del_map(t_map **head)
{
	ft_del_coor((*head)->start_);
	ft_deltab_int((*head)->map_);
	free(*head);
	*head = NULL;
}

void		ft_del_env(t_env **env)
{
	free((*env)->core_);
	free(*env);
	*env = NULL;
}
