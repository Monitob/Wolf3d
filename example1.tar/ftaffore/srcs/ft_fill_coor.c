/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fill_coor.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ftaffore <ftaffore@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/05 09:52:54 by ftaffore          #+#    #+#             */
/*   Updated: 2013/12/19 14:41:30 by ftaffore         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<stdio.h>
#include	"libft.h"
#include	"fdf.h"

static int	my_fill_coor2d(t_map *head, int xx, int yy, int z)
{
	t_coor	*ptr;
	t_coor	*new;
	float	x;
	float	y;

	x = head->size_l_ * (xx % head->length_);
	y = head->size_h_ * yy;
	ptr = head->start_;
	if ((new = (t_coor *)ft_memalloc(sizeof(*new))) == NULL)
		return (0);
	while (ptr != NULL && ptr->next != NULL)
		ptr = ptr->next;
	if (ptr == NULL)
		head->start_ = new;
	else
		ptr->next = new;
	new->z_ = z;
	z = -z * 3;
	new->x_ = CTE1 * x - CTE2 * y + WIN_SIZE / 2;
	new->y_ = z + ((CTE1 / 2) * x) + ((CTE2 / 2) * y) + (WIN_SIZE / 8);
	new->next = NULL;
	if (new->x_ <= 0 || new->y_ <= 0 || new->x_ >= WIN_SIZE \
		|| new->y_ >= WIN_SIZE)
		return (0);
	return (1);
}

t_map		*ft_fill_coor(t_map *head)
{
	int		x;
	int		y;

	y = 0;
	head->size_h_ = (WIN_SIZE - WIN_SIZE / 4) / head->height_;
	head->size_l_ = (WIN_SIZE - WIN_SIZE / 4) / head->length_;
	while (y < head->height_)
	{
		x = 0;
		while (x < head->length_)
		{
			if (my_fill_coor2d(head, x, y, head->map_[y][x]) == 0)
			{
				ft_putstr_fd("z too large for the window\n", 2);
				return (NULL);
			}
			x++;
		}
		y++;
	}
	return (head);
}
