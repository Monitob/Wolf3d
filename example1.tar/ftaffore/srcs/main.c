/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ftaffore <ftaffore@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/04 14:27:31 by ftaffore          #+#    #+#             */
/*   Updated: 2014/01/14 20:49:35 by jbernabe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<fcntl.h>
#include	<stdlib.h>
#include	"libft.h"
#include	"fdf.h"

int			main(int ac, char **av)
{
	t_map	*head;
	int		fd;

	head = NULL;
	if (ac > 1)
	{
		if ((fd = ft_open(av[1], O_RDONLY)) < 0)
			return (0);
		if ((head = ft_fill_map(fd, head)) == NULL)
			return (0);
		if (ft_close(fd) < 0)
			return (0);
		if (head->height_ < 2 || head->length_ < 2)
		{
			ft_putstr_fd("ERROR: ", 2);
			ft_putstr_fd(av[1], 2);
			ft_putendl_fd(": is not a valid map.", 2);
			return (0);
		}
		if ((head = ft_fill_coor(head)) == NULL)
			return (0);
		if (ft_display_map(head) == 0)
			return (0);
	}
	return (1);
}
