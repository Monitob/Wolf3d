/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display_map.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ftaffore <ftaffore@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/05 11:21:54 by ftaffore          #+#    #+#             */
/*   Updated: 2014/01/14 22:22:56 by jbernabe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<stdlib.h>
#include	<mlx.h>
#include	"libft.h"
#include	"fdf.h"

int			key_hook(int keycode, t_env *env)
{
	if (keycode == 65307)
	{
		mlx_destroy_image(env->core_, env->img_);
		mlx_destroy_window(env->core_, env->win_);
		ft_del_env(&env);
		exit(0);
	}
	return (0);
}

int			expose_hook(t_env *env)
{
	if (mlx_put_image_to_window(env->core_, env->win_, env->img_, 0, 0) == 0)
		exit(0);
	return (0);
}

static void	ft_fill_img(t_env *env, t_map *head)
{
	t_coor	*ptr;
	t_coor	*ptr2;
	int		i;

	i = 1;
	ptr = head->start_;
	ptr2 = ptr;
	while (ptr != NULL && ptr->next != NULL)
	{
		if (i % head->length_ != 0)
			ft_draw_line(env, ptr, ptr->next);
		if (i > head->length_)
		{
			ft_draw_line(env, ptr, ptr2);
			ptr2 = ptr2->next;
		}
		ptr = ptr->next;
		i++;
	}
	ft_draw_line(env, ptr, ptr2);
}

static int	ft_create_img(t_env *env)
{
	int		bpp;
	int		sizeline;
	int		endian;

	bpp = 0;
	sizeline = 0;
	endian = 0;
	if ((env->img_ = mlx_new_image(env->core_, WIN_SIZE, WIN_SIZE)) == NULL)
		return (0);
	env->data_ = mlx_get_data_addr(env->img_, &bpp, &sizeline, &endian);
	if (env->data_ == NULL)
		return (0);
	env->bpp_ = bpp;
	env->sizeline_ = sizeline;
	env->endian_ = endian;
	return (1);
}

int			ft_display_map(t_map *head)
{
	t_env	*env;

	if ((env = (t_env *)ft_memalloc(sizeof(*env))) == NULL)
		return (0);
	if ((env->core_ = mlx_init()) == NULL)
		return (0);
	env->win_ = mlx_new_window(env->core_, WIN_SIZE, WIN_SIZE, "fdf");
	if (env->win_ == NULL)
		return (0);
	env->color_ = mlx_get_color_value(env->core_, COLOR);
	if (ft_create_img(env) == 0)
		return (0);
	ft_fill_img(env, head);
	ft_del_map(&head);
	mlx_key_hook(env->win_, key_hook, env);
	mlx_expose_hook(env->win_, expose_hook, env);
	mlx_loop(env->core_);
	return (1);
}
