/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_draw_line.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ftaffore <ftaffore@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/05 12:27:41 by ftaffore          #+#    #+#             */
/*   Updated: 2013/12/20 16:46:16 by ftaffore         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include			<stdlib.h>
#include			<mlx.h>
#include			"libft.h"
#include			"fdf.h"

static void			my_put_pixel_img(t_env *e, int x, int y, float z)
{
	unsigned long	color;
	unsigned char	*src;

	color = 0xFFFFAA0;
	src = (unsigned char *)(&color);
	src[2] = src[2] - (z * 256 / 11);
	src[1] = src[1] - (z * 256 / 11);
	e->data_[y * e->sizeline_ + x * e->bpp_ / 8 ] = src[0];
	e->data_[y * e->sizeline_ + x * e->bpp_ / 8 + 1] = src[1];
	e->data_[y * e->sizeline_ + x * e->bpp_ / 8 + 2] = src[2];
}

static void			my_draw_h(t_env *env, t_coor *p1, t_coor *p2, t_info *i)
{
	int				x;
	int				y;
	float			z;

	x = p1->x_;
	z = p1->z_;
	if (p1->x_ < p2->x_)
	{
		while (x < p2->x_)
		{
			y = p1->y_ + ((p2->y_ - p1->y_) * (x - p1->x_)) / (p2->x_ - p1->x_);
			my_put_pixel_img(env, x, y, z);
			z += i->mul * i->inv * i->norme;
			x++;
		}
		return ;
	}
	while (x > p2->x_)
	{
		y = p1->y_ + ((p2->y_ - p1->y_) * (x - p1->x_)) / (p2->x_ - p1->x_);
		my_put_pixel_img(env, x, y, z);
		z += i->mul * i->inv * i->norme;
		x--;
	}
}

static void		my_draw_v(t_env *env, t_coor *p1, t_coor *p2, t_info *i)
{
	int			x;
	int			y;
	float		z;

	y = p1->y_;
	z = p1->z_;
	if (p1->y_ < p2->y_)
	{
		while (y < p2->y_)
		{
			x = p1->x_ + ((p2->x_ - p1->x_) * (y - p1->y_)) / (p2->y_ - p1->y_);
			my_put_pixel_img(env, x, y, z);
			z += i->mul * i->inv * i->norme;
			y++;
		}
		return ;
	}
	while (y > p2->y_)
	{
		x = p1->x_ + ((p2->x_ - p1->x_) * (y - p1->y_)) / (p2->y_ - p1->y_);
		my_put_pixel_img(env, x, y, z);
		z += i->mul * i->inv * i->norme;
		y--;
	}
}

static void		my_draw_exeption(t_env *env, t_coor *p1, t_coor *p2)
{
	int			x;
	int			y;

	x = p1->x_;
	y = p1->y_;
	if (p1->x_ == p2->x_ || p1->y_ == p2->y_)
	{
		while ((x <= p2->x_) && (y <= p2->y_))
		{
			my_put_pixel_img(env, x, y, 0);
			y += (p1->x_ == p2->x_) ? (1) : (0);
			x += (p1->y_ == p2->y_) ? (1) : (0);
		}
	}
	else
	{
		while (x < p2->x_)
		{
			my_put_pixel_img(env, x, y, 0);
			y += (p1->y_ < p2->y_) ? (1) : (-1);
			x++;
		}
	}
}

void			ft_draw_line(t_env *env, t_coor *p1, t_coor *p2)
{
	t_info		info;
	float		nx;

	nx = NORME(p1->x_, p2->x_);
	nx = nx - (NORME(p1->y_, p2->y_));
	info.mul = MUL(p2->z_, p1->z_);
	info.norme = NORME(p1->z_, p2->z_);
	info.inv = INVERSE(p1->x_, p2->x_);
	if (nx > 0)
	{
		if (p1->x_ == p2->x_)
			my_draw_exeption(env, p1, p2);
		else
			my_draw_h(env, p1, p2, &info);
	}
	else if (nx < 0)
	{
		info.inv = INVERSE(p1->y_, p2->y_);
		if (p1->y_ == p2->y_)
			my_draw_exeption(env, p1, p2);
		else
			my_draw_v(env, p1, p2, &info);
	}
	else
		my_draw_exeption(env, p1, p2);
}
