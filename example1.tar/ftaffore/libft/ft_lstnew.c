/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstnew.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ftaffore <ftaffore@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/25 13:26:34 by ftaffore          #+#    #+#             */
/*   Updated: 2013/11/25 13:31:55 by ftaffore         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<stdlib.h>
#include	"libft.h"

t_list		*ft_lstnew(void const *content, size_t content_size)
{
	t_list	*new;

	if ((new = (t_list)(malloc(content_size))) == NULL)
		return (NULL);
	new->content_size = content_size;
	new->content = ft_memcpy(content);
	if (new->content == NULL)
		new->content_size = 0;
	new->next = NULL;
	return (new);
}
