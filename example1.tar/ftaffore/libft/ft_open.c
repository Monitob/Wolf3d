/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_open.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ftaffore <ftaffore@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/05 15:05:34 by ftaffore          #+#    #+#             */
/*   Updated: 2013/12/05 15:10:00 by ftaffore         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<stdio.h>
#include	<fcntl.h>
#include	"libft.h"

int			ft_open(const char *name, int flags)
{
	int		fd;

	if ((fd = open(name, flags)) < 0)
		perror("open :");
	return (fd);
}
