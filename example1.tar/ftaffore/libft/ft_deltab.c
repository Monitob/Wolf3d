/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_deltab.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ftaffore <ftaffore@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/05 15:01:08 by ftaffore          #+#    #+#             */
/*   Updated: 2014/01/14 20:49:33 by jbernabe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<stdio.h>
#include	<stdlib.h>
#include	"libft.h"

void		ft_deltab(char **s)
{
	int		i;

	i = 0;
	if (s != NULL)
	{
		while (s[i] != NULL)
		{
			free(s[i]);
			i++;
		}
		free(s[i]);
		free(s);
	}
}
