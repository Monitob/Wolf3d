/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ftaffore <ftaffore@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/25 13:52:24 by ftaffore          #+#    #+#             */
/*   Updated: 2013/11/25 13:58:50 by ftaffore         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	"libft.h"

t_list		*ft_lstmap(t_list *lst, t_list *(*f)(t_list *elem))
{
	t_list	*res;
	t_list	*ptr;
	t_list	*new;

	ptr = lst;
	new = NULL;
	res = new;
	while (ptr != NULL)
	{
		new = f(ptr);
		ptr = ptr->next;
		new = new->next;
	}
	return (res);
}
