/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_deltab_int.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ftaffore <ftaffore@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/05 15:03:27 by ftaffore          #+#    #+#             */
/*   Updated: 2014/01/14 20:49:32 by jbernabe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<stdlib.h>
#include	"libft.h"

void		ft_deltab_int(int **t)
{
	int		i;

	i = 0;
	if (t != NULL)
	{
		while (t[i] != NULL)
		{
			free(t[i]);
			i++;
		}
		free(t[i]);
		free(t);
	}
}
