/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/04 13:30:54 by glavanan          #+#    #+#             */
/*   Updated: 2014/02/15 20:41:40 by jbernabe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "rtv1.h"

double	ft_car(double nb)
{
	return (nb * nb);
}

int		ft_put_p4(t_cal *cal, double x, double y)
{
	int		i;

	i = y * WD_H * 4 + x * 4;
	cal->pix[i++] = 0x00;
	cal->pix[i++] = 0xFF;
	cal->pix[i++] = 0xFF;
	return (0);
}


int		ft_put_p3(t_cal *cal, double x, double y)
{
	int		i;

	i = y * WD_H * 4 + x * 4;
	cal->pix[i++] = 0xFF;
	cal->pix[i++] = 0xFF;
	cal->pix[i++] = 0x00;
	return (0);
}

int		ft_put_p2(t_cal *cal, double x, double y)
{
	int		i;

	i = y * WD_H * 4 + x * 4;
	cal->pix[i++] = 0xFF;
	cal->pix[i++] = 0x00;
	cal->pix[i++] = 0xFF;
	return (0);
}

int		ft_put_p(t_cal *cal, double x, double y)
{
	int		i;

	i = y * WD_H * 4 + x * 4;
	cal->pix[i++] = cal->col->col1;
	cal->pix[i++] = cal->col->col2;
	cal->pix[i++] = cal->col->col3;
	return (0);
}

double		ft_put_cyl(t_cal *cal, int x, int y, int r)
{
	double		tmp[5];

	tmp[0] = (ft_car(cal->cam->rayx) + ft_car(cal->cam->rayy));
	tmp[1] = 2 * (cal->cam->rayx * (cal->cam->camx - x) +
			(cal->cam->camy - y) * cal->cam->rayy);
	tmp[2] = ft_car(cal->cam->camx - x) + ft_car(cal->cam->camy - y)
		- ft_car(r);
	tmp[3] = (- tmp[1] - sqrt(ft_car(tmp[1]) - 4 * tmp[0] * tmp[2]))
		/ (2 * tmp[0]);
	return (tmp[3]);
}

void	ft_cal_cy(double vec[3], double ve2[3], t_cal *cal, double ret)
{
	double	indice;

	(void)ret;
	indice = (vec[0] * ve2[0]) + (vec[1] * ve2[1]) + (vec[2] * ve2[2]);
	if (cos(indice) >= 0.0001)
	{
		cal->col->col1 = cal->col->colv1 * (-cos(indice) + 0.25);
		cal->col->col2 = cal->col->colv2 * (-cos(indice) + 0.25);
		cal->col->col3 = cal->col->colv3 * (-cos(indice) + 0.25);
	}
	else
	{
		cal->col->col1 = 0x00;
		cal->col->col2 = 0x00;
		cal->col->col3 = 0x00;
	}
}

void	ft_cal_lum_cy(t_cal *cal, int x, int y, int r, double ret)
{
	double	pos[3];
	double	vec[3];
	double	ve2[3];
	double	norm;

	(void)r;
	pos[0] = cal->cam->camx + (cal->cam->rayx * ret);
	pos[1] = cal->cam->camy + (cal->cam->rayy * ret);
	pos[2] = cal->cam->camz + (cal->cam->rayz * ret);
	vec[0] = pos[0] - cal->sp->posx;
	vec[1] = pos[1] - cal->sp->posy;
	vec[2] = pos[2] - POSZ;
	norm = sqrt(ft_car(vec[0]) + ft_car(vec[1]) + ft_car(vec[2]));
	vec[0] = vec[0] / norm;
	vec[1] = vec[1] / norm;
	vec[2] = vec[2] / norm;
	ve2[0] = x - pos[0];
	ve2[1] = y - pos[1];
	ve2[2] = 0;
	norm = sqrt(ft_car(ve2[0]) + ft_car(ve2[1]) + ft_car(ve2[2]));
	ve2[0] = ve2[0] / norm;
	ve2[1] = ve2[1] / norm;
	ve2[2] = ve2[2] / norm;
	ft_cal_cy(ve2, vec, cal, ret);
}

double		ft_put_sphere(t_cal *cal, int sp[4])
{
	double		tmp[5];

	tmp[0] = ((cal->cam->rayx * cal->cam->rayx) + (cal->cam->rayy
				* cal->cam->rayy) + (cal->cam->rayz * cal->cam->rayz));
	tmp[1] = 2 * (((cal->cam->camx - sp[0]) * cal->cam->rayx)
			+ ((cal->cam->camy - sp[1]) * cal->cam->rayy)
			+ ((cal->cam->camz - sp[2]) * cal->cam->rayz));
	tmp[2] = (((cal->cam->camx - sp[0]) * (cal->cam->camx - sp[0]))
			+ ((cal->cam->camy - sp[1])
				* (cal->cam->camy - sp[1])) + ((cal->cam->camz - sp[2])
				* (cal->cam->camz - sp[2]))) - (sp[3] * sp[3]);
	tmp[3] = tmp[1] * tmp[1] - (4 * tmp[0] * tmp[2]);
	if (tmp[3] >= 0)
	{
		tmp[4] = (-tmp[1] - sqrt(tmp[3])) / (2 * tmp[0]);
		return (tmp[4]);
	}
	return (0);
}


void	ft_cal_as(double vec[3], double ve2[3], t_cal *cal, double ret)
{
	double	indice;

	(void)ret;
	indice = (vec[0] * ve2[0]) + (vec[1] * ve2[1]) + (vec[2] * ve2[2]);
	if (cos(indice) >= 0)
	{
		cal->col->col1 = cal->col->colb1 * (-cos(indice) + 0.25);
		cal->col->col2 = cal->col->colb2 * (-cos(indice) + 0.25);
		cal->col->col3 = cal->col->colb3 * (-cos(indice) + 0.25);
	}
	else
	{
		cal->col->col1 = 0x00;
		cal->col->col2 = 0x00;
		cal->col->col3 = 0x00;
	}
}

void	ft_cal_lum_sp(t_cal *cal, int sp[5], double ret)
{
	double	pos[3];
	double	vec[3];
	double	ve2[3];
	double	norm;

	pos[0] = cal->cam->camx + cal->cam->rayx * ret;
	pos[1] = cal->cam->camy + cal->cam->rayy * ret;
	pos[2] = cal->cam->camz + cal->cam->rayz * ret;
	vec[0] = pos[0] - cal->sp->posx;
	vec[1] = pos[1] - cal->sp->posy;
	vec[2] = pos[2] - POSZ;
	norm = sqrt(ft_car(vec[0]) + ft_car(vec[1]) + ft_car(vec[2]));
	vec[0] = vec[0] / norm;
	vec[1] = vec[1] / norm;
	vec[2] = vec[2] / norm;
	ve2[0] = pos[0] - sp[0];
	ve2[1] = pos[1] - sp[1];
	ve2[2] = pos[2] - sp[2];
	norm = sqrt(ft_car(ve2[0]) + ft_car(ve2[1]) + ft_car(ve2[2]));
	ve2[0] = ve2[0] / norm;
	ve2[1] = ve2[1] / norm;
	ve2[2] = ve2[2] / norm;
	ft_cal_as(ve2, vec, cal, ret);
}


void	ft_cal_co(double vec[3], double ve2[3], t_cal *cal, double ret)
{
	double	indice;

	(void)ret;
	indice = (vec[0] * ve2[0]) + (vec[1] * ve2[1]) + (vec[2] * ve2[2]);
	if (cos(indice) >= 0.0001)
	{
		cal->col->col1 = cal->col->colj1 * (-cos(indice) + 0.25);
		cal->col->col2 = cal->col->colj2 * (-cos(indice) + 0.25);
		cal->col->col3 = cal->col->colj3 * (-cos(indice) + 0.25);
	}
	else
	{
		cal->col->col1 = 0x00;
		cal->col->col2 = 0x00;
		cal->col->col3 = 0x00;
	}
}


void	ft_cal_lum_co(t_cal *cal, int x, int y, int z, int r, double ret)
{
	double	pos[3];
	double	vec[3];
	double	ve2[3];
	double	norm;

	pos[0] = cal->cam->camx + (cal->cam->rayx * ret);
	pos[1] = cal->cam->camy + (cal->cam->rayy * ret);
	pos[2] = cal->cam->camz + (cal->cam->rayz * ret);
	vec[0] = pos[0] - cal->sp->posx;
	vec[1] = pos[1] - cal->sp->posy;
	vec[2] = pos[2] - POSZ;
	norm = sqrt(ft_car(vec[0]) + ft_car(vec[1]) + ft_car(vec[2]));
	vec[0] = vec[0] / norm;
	vec[1] = vec[1] / norm;
	vec[2] = vec[2] / norm;
	ve2[0] = x - pos[0];
	ve2[1] = y - pos[1];
	ve2[2] = -(z - pos[2]) * tan(ft_car((M_PI * r) / 180));
	norm = sqrt(ft_car(ve2[0]) + ft_car(ve2[1]) + ft_car(ve2[2]));
	ve2[0] = ve2[0] / norm;
	ve2[1] = ve2[1] / norm;
	ve2[2] = ve2[2] / norm;
	ft_cal_co(ve2, vec, cal, ret);
}

double		ft_put_cone(int x, int y, int z, int r, t_cal *cal)
{
	double		tmp[5];

	tmp[0] = (ft_car(cal->cam->rayx) - (ft_car(cal->cam->rayy) * ft_car(r))
			+ ft_car(cal->cam->rayz));
	tmp[1] = 2 * ((cal->cam->camx - x) * cal->cam->rayx - (((cal->cam->camy - y)
					* cal->cam->rayy) * ft_car(r)) + (cal->cam->camz - z)
			* cal->cam->rayz);
	tmp[2] = ft_car(cal->cam->camx - x) - (ft_car(cal->cam->camy - y)
			* ft_car(r)) + ft_car(cal->cam->camz - z);
	tmp[3] = ft_car(tmp[1]) - (4 * tmp[0] * tmp[2]);
	tmp[4] = (- tmp[1] - sqrt(tmp[3])) / (2 * tmp[0]);
	return (tmp[4]);
}

void	ft_cal_pl(double vec[3], double ve2[3], t_cal *cal, double ret)
{
	double	indice;

	(void)ret;
	indice = (vec[0] * ve2[0]) + (vec[1] * ve2[1]) + (vec[2] * ve2[2]);
	if (cos(indice) >= 0.0001)
	{
		cal->col->col1 = cal->col->colr1 * (-cos(indice) + 0.25);
		cal->col->col2 = cal->col->colr2 * (-cos(indice) + 0.25);
		cal->col->col3 = cal->col->colr3 * (-cos(indice) + 0.25);
	}
	else
	{
		cal->col->col1 = 0x00;
		cal->col->col2 = 0x00;
		cal->col->col3 = 0x00;
	}
}


void	ft_cal_lum_pl(t_cal *cal, int x, int y, int z, double ret)
{
	double	pos[3];
	double	vec[3];
	double	ve2[3];
	double	norm;

	pos[0] = cal->cam->camx + (cal->cam->rayx * ret);
	pos[1] = cal->cam->camy + (cal->cam->rayy * ret);
	pos[2] = cal->cam->camz + (cal->cam->rayz * ret);
	vec[0] = pos[0] - cal->sp->posx;
	vec[1] = pos[1] - cal->sp->posy;
	vec[2] = pos[2] - POSZ;
	norm = sqrt(ft_car(vec[0]) + ft_car(vec[1]) + ft_car(vec[2]));
	vec[0] = vec[0] / norm;
	vec[1] = vec[1] / norm;
	vec[2] = vec[2] / norm;
	ve2[0] = 0;
	ve2[1] = 0;
	ve2[2] = -(x * cal->cam->rayx + y * cal->cam->rayy + z * cal->cam->rayz);
	norm = sqrt(ft_car(ve2[0]) + ft_car(ve2[1]) + ft_car(ve2[2]));
	ve2[0] = ve2[0] / norm;
	ve2[1] = ve2[1] / norm;
	ve2[2] = ve2[2] / norm;
	ft_cal_pl(ve2, vec, cal, ret);
}

double		ft_put_plan(int x, int y, int z, t_cal *cal)
{
	double		tmp[3];

	tmp[0] = (x * (cal->cam->camx - 0) + y * (cal->cam->camy + 20)
			+ z * (cal->cam->camz - 0) + 20);
	tmp[1] = (x * cal->cam->rayx + y * cal->cam->rayy + z * cal->cam->rayz);
	tmp[2] = -(tmp[0] / tmp[1]);
	return (tmp[2]);
}

void	ft_calc_ray(t_cal *cal, int x, int y)
{
	cal->cam->rayx = (cal->cam->upx - cal->cam->camx) + cal->cam->rivx
		* cal->cam->wv / WD_H * x - cal->cam->upvx * cal->cam->hv / WD_W * y;
	cal->cam->rayy = (cal->cam->upy - cal->cam->camy) + cal->cam->rivy
		* cal->cam->wv / WD_H * x - cal->cam->upvy * cal->cam->hv / WD_W * y;
	cal->cam->rayz = (cal->cam->upz - cal->cam->camz) + cal->cam->rivz
		* cal->cam->wv / WD_H * x - cal->cam->upvz * cal->cam->hv / WD_W * y;
}

void	ft_plann(t_cal *cal)
{
	cal->cam->upx = cal->cam->camx + ((cal->cam->dp * cal->cam->vecdx)
			+ (cal->cam->hv / 2) * cal->cam->upvx) - ((cal->cam->wv / 2)
			* cal->cam->rivx);
	cal->cam->upy = cal->cam->camy + ((cal->cam->dp * cal->cam->vecdy)
			+ (cal->cam->hv / 2) * cal->cam->upvy) - (cal->cam->wv / 2)
		* cal->cam->rivy;
	cal->cam->upz = cal->cam->camz + ((cal->cam->dp * cal->cam->vecdz)
			+ (cal->cam->hv / 2) * cal->cam->upvz) - (cal->cam->wv / 2)
		* cal->cam->rivz;
	cal->col->colb1 = (cal->col->colr3 = (cal->col->colv2 = (cal->col->colj1
		= (cal->col->colj3 = 0xFF))));
	cal->col->colj2 = cal->col->colr2 = cal->col->colr1 = cal->col->colb2
		= cal->col->colb3 = cal->col->colv1 = cal->col->colv3 = 0x00;
}

void	ft_plan(t_cal *cal)
{
	double		longvec;

	cal->cam->vecdx = ((double)cal->cam->dirx - (double)cal->cam->camx);
	cal->cam->vecdy = ((double)cal->cam->diry - (double)cal->cam->camy);
	cal->cam->vecdz = ((double)cal->cam->dirz - (double)cal->cam->camz);
	longvec = sqrt(ft_car(cal->cam->vecdx) + ft_car(cal->cam->vecdy)
			+ ft_car(cal->cam->vecdz));
	cal->cam->vecdx = cal->cam->vecdx / longvec;
	cal->cam->vecdy = cal->cam->vecdy / longvec;
	cal->cam->vecdz = cal->cam->vecdz / longvec;
	cal->cam->upvx = cal->cam->camx;
	cal->cam->upvy = cal->cam->camy + 1.0;
	cal->cam->upvz = cal->cam->camz;
	cal->cam->rivx = (cal->cam->vecdy * cal->cam->upvz)
		- (cal->cam->vecdz * cal->cam->upvy);
	cal->cam->rivy = (cal->cam->vecdz * cal->cam->upvx)
		- (cal->cam->vecdx * cal->cam->upvz);
	cal->cam->rivz = (cal->cam->vecdx * cal->cam->upvy)
		- (cal->cam->vecdy * cal->cam->upvx);
	ft_plann(cal);
}

void	ft_ini(t_cal *cal)
{
	cal->cam = (t_cam *)malloc(sizeof(cal->cam));
	cal->vp = (t_vp *)malloc(sizeof(cal->vp));
	cal->sp = (t_sp *)malloc(sizeof(cal->sp));
	cal->col = (t_col *)malloc(sizeof(cal->col));
	cal->cam->camx = 0;
	cal->cam->camy = 0;
	cal->cam->camz = 0;
	cal->cam->fov = -((WD_H / 2) / (tan(15)));
	cal->cam->dirx = cal->cam->camx + 0;
	cal->cam->diry = cal->cam->camy + 0;
	cal->cam->dirz = cal->cam->camz + 50;
	cal->cam->dp = 1.0;
	cal->cam->hv = 0.35;
	cal->cam->wv = 0.5;
	cal->sp->posx = 30.0;
	cal->sp->posy = 300.0;
	cal->sp->posz = 300.0;
	ft_plan(cal);
}

void	ft_create_scenen(t_cal *cal, int x, int y, double ret)
{
	double	ret2;

	ret2 = 0;
	if ((ret2 = ft_put_cyl(cal, 10, 20, 10)) >= 0.00001)
	{
		if (ret >= 0.00001 && ret2 > ret);
		else
		{
			ft_cal_lum_cy(cal, 10, 20, 10, ret2);
			ft_put_p(cal, x, y);
			ret = ret2;
		}
	}
	if ((ret2 = ft_put_cone(10, 0, 600, 1, cal)) >= 0.00001)
	{
		if (ret >= 0.00001 && ret2 > ret);
		else
		{
			ft_cal_lum_co(cal, 10, 0, 600, 1, ret2);
			ft_put_p(cal, x, y);
			ret = ret2;
		}
	}
}

void	ft_create_scene(t_cal *cal, int x, int y)
{
	int			sp[5];
	double		ret;
	double		ret2;

	sp[0] = 0;
	sp[1] = 20;
	sp[2] = 600;
	sp[3] = 80;
	ret = 0;
	ret2 = 0;
	ft_calc_ray(cal, x, y);
	if ((ret = ft_put_sphere(cal, sp)) >= 0.00001)
	{
		ft_cal_lum_sp(cal, sp, ret);
		ft_put_p(cal, x, y);
	}
	if ((ret2 = ft_put_plan(0, 1, 0, cal)) >= 0.00001)
	{
		if (ret >= 0.00001 && ret2 > ret);
		else
		{
			ft_cal_lum_pl(cal, 0, 1, 0, ret2);
			ft_put_p(cal, x, y);
			ret = ret2;
		}
	}
	ft_create_scenen(cal, x, y, ret);
}

void	ft_draw(t_cal *cal)
{
	int			x;
	int			y;
	int			z;

	ft_ini(cal);
	z = cal->cam->fov;
	x = 0;
	while (x < WD_H)
	{
		y = 0;
		while (y < WD_W)
		{
			ft_create_scene(cal, x, y);
			y++;
		}
	x++;
	}
	free(cal->sp);
}
