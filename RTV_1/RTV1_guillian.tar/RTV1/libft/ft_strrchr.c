/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 09:34:16 by glavanan          #+#    #+#             */
/*   Updated: 2013/12/01 23:15:38 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>

char	*ft_strrchr(char const *s, int c)
{
	int		i;
	int		i2;

	i2 = -1;
	i = 0;
	while (s[i] != '\0')
	{
		if (s[i] == c)
			i2 = i;
		i++;
	}
	if (i2 != -1)
		return ((char*)(s + i2));
	if (c == '\0')
		return ((char*)(s + i));
	return (NULL);
}

