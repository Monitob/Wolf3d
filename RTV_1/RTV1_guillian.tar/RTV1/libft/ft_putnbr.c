/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/29 13:00:44 by glavanan          #+#    #+#             */
/*   Updated: 2013/12/26 15:54:23 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdlib.h>

void	ft_putnbr(int n)
{
	int		s;
	int		tilt;

	s = 1;
	tilt = 0;
	if (n < 0)
	{
		n = n * (-1);
		tilt = 1;
	}
	while ((n / s) > 9)
	{
		s = s * 10;
	}
	if (tilt)
		ft_putchar('-');
	while (s != 0)
	{
		ft_putchar('0' + (n / s) % 10);
		s = s / 10;
	}
}

