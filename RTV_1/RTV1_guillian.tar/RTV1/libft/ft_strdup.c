/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/19 15:18:34 by glavanan          #+#    #+#             */
/*   Updated: 2013/12/01 23:03:36 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdlib.h>

char	*ft_strdup(const char *s)
{
	int		i;
	int		c;
	char	*d;

	c = 0;
	i = ft_strlen(s);
	d = (char *)malloc(sizeof(*s) * (i));
	while (s[c] != '\0')
	{
		d[c] = s[c];
		c++;
		d[c] = s[c];
	}
	return (d);
}

