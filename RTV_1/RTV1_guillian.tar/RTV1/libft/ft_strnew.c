/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnew.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/27 13:07:22 by glavanan          #+#    #+#             */
/*   Updated: 2013/12/30 13:58:18 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdlib.h>

char	*ft_strnew(size_t size)
{
	char	*d;

	d = NULL;
	if (size != '0')
		d = (char *)malloc(sizeof(*d) * size + 1);
	if (d == NULL)
		return (NULL);
	while (size--)
		d[(int)size] = '\0';
	return (d);
}

