/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 16:55:26 by glavanan          #+#    #+#             */
/*   Updated: 2013/12/01 23:25:14 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdlib.h>

void	*ft_memccpy(void *dest, const void *src, int c, size_t n)
{
	int		i;

	i = 0;
	if (dest && src && n)
	{
		while (n > 0 && *((char *)src + i) != c)
		{
			*((char *)dest + i) = *((char *)src + i);
			i++;
			n--;
		}
		if (*((char *)src + i) == c)
		{
			*((char *)dest + i) = *((char *)src + i);
			return (((void *)dest + i + 1));
		}
		else
		{
			return (NULL);
		}
	}
	return (NULL);
}

