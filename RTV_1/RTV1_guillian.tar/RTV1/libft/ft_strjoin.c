/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/24 10:22:40 by glavanan          #+#    #+#             */
/*   Updated: 2013/12/19 16:00:42 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "libft.h"
#include <string.h>

char	*ft_strjoin(char const *s, char const *s2)
{
	char	*str;
	int		i;

	i = 0;
	str = (char *)malloc(sizeof(str) * (int)(ft_strlen(s) + ft_strlen(s2)));
	if (str == NULL)
		return (NULL);
	while (i <= (int)(ft_strlen(s)))
	{
		str[i] = s[i];
		i++;
	}
	str = ft_strcat(str, s2);
	str[ft_strlen(s) + ft_strlen(s2)] = '\0';
	return (str);
}

