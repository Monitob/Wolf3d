/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_env.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/03 12:45:20 by glavanan          #+#    #+#             */
/*   Updated: 2014/02/03 16:21:38 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

int		ft_file_param(t_obj *obj, char *str, int ret)
{
	char	*nbr;
	int		i;

	i = 0;
	nbr = (char *)malloc(sizeof(char) * ft_strlen(str));
	while (str[ret] != '\t')
	{
		ft_putchar(str[ret]);
		nbr[i] = str[ret];
		ret = ret + 1;
		i++;
	}
	nbr[i] = '\0';
	obj->type = ft_atoi(nbr);
	ret = ret + 1 + (i = 0);
	while (str[ret] != '\t')
	{
		nbr[i] = str[ret];
		ret = ret + 1;
		i++;
	}
	nbr[i] = '\0';
	obj->size = ft_atoi(nbr);
	ret = ft_file_param_next(obj, str, ret, nbr);
	return (ret);
}

int		ft_init_obj(t_obj *obj, char *str, int ret)
{
	ret = ft_file_param(obj, str, ret);
	obj->next = NULL;
	obj->prev = NULL;
	return (ret);
}

int		ft_file(t_obj *obj, char *str, int ret)
{
	t_obj	*tmp;


	ret++;
	if (obj->pos == -1)
	{
		obj->pos = 0;
		ret = ft_init_obj(obj, str, ret);
	}
	else
	{
		tmp = (t_obj *)malloc(sizeof(t_obj));
		while (obj->next != NULL)
			obj = obj->next;
		tmp->pos = obj->pos + 1;
		ret = ft_init_obj(tmp, str, ret);
		obj->next = tmp;
		tmp->prev = obj;
	}
	return (ret);
}

int		ft_read_file(int fd, t_cal *cal, t_obj *obj)
{
	int		ret;
	char	buf[1025];
	char	*tmp;
	char	*str;

	str = (char *)malloc(sizeof(char) * 1);
	ret = 0;
	str[0] = '\0';
	while ((ret = read(fd, buf, 1024)) > 0)
	{
		buf[ret] = '\0';
		tmp = ft_strjoin(str, buf);
		free(str);
		str = tmp;
	}
	if (ret == - 1)
		return (0);
	ret = 0;
	ft_file(obj, str, ret);
	while (str[ret++])
	{
		if (str[ret] == '\n' && str[ret + 1] != '\0')
			ft_file(obj, str, ret + 1);
	}
	(void)cal;
	return (1);
}

int		ft_select_env(int argc, char **argv, t_cal *cal, t_obj *obj)
{
	int		fd;

	obj = (t_obj *)malloc(sizeof(t_obj));
	obj->pos = -1;
	if (argc == 1)
	{
		ft_putstr_fd("usage : ./rtv1 file\n", 2);
		return (0);
	}
	if (argc > 2)
	{
		ft_putstr("only : ");
		ft_putstr(argv[1]);
		ft_putstr(" will be open\n");
	}
	if ((fd = open(argv[1], O_RDONLY)) == -1)
	{
		ft_putstr("can't open file");
		return (0);
	}
	ft_putstr("selesct_env\n");
	return (ft_read_file(fd, cal, obj));
}
