/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   wall_define.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/17 07:04:10 by gtandeo           #+#    #+#             */
/*   Updated: 2014/01/17 07:04:11 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf.h"

void		wall_detection(t_aff *e)
{
	e->touche = 0;
	if (e->rayDirX < 0)
	{
		e->etapeX = -1;
		e->distMurX = (e->rayPosX - e->mapX) * e->dist2MurX;
	}
	else
	{
		e->etapeX = 1;
		e->distMurX = (e->mapX + 1.0 - e->rayPosX) * e->dist2MurX;
	}

	if (e->rayDirY < 0)
	{
		e->etapeY = -1;
		e->distMurY = (e->rayPosY - e->mapY) * e->dist2MurY;
	}
	else
	{
		e->etapeY = 1;
		e->distMurY = (e->mapY + 1.0 - e->rayPosY) * e->dist2MurY;
	}
}

void		you_shall_not_past(t_aff *e)
{
	e->wall_type = 0;
	while (e->touche == 0)
	{
		if (e->distMurX < e->distMurY)
		{
			e->distMurX += e->dist2MurX;
			e->mapX += e->etapeX;
			e->wall_type = 0;
		}
		else
		{
			e->distMurY += e->dist2MurY;
			e->mapY += e->etapeY;
			e->wall_type = 1;
		}
		if (e->map[e->mapX][e->mapY] != '0')
			e->touche = 1;
	}
}
