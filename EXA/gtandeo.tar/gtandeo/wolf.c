/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   wolf.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/17 06:04:12 by gtandeo           #+#    #+#             */
/*   Updated: 2014/01/17 06:04:13 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf.h"

int			expose_hook(t_aff *e)
{
	e->x = 0;
	while (e->x < e->w)
	{
		e->drawStart = 0;
		e->drawEnd = e->h / 2;
		e->color = 0x5EB6DD;
		draw(e);
		e->drawStart = e->h / 2;
		e->drawEnd = e->h;
		e->color = 0x663E10;
		draw(e);
		e->x++;
	}
	ft_ray(e);
	mlx_put_image_to_window(e->mlx, e->win, e->img, 0, 0);
	return (0);
}

void		ft_initray(t_aff *e)
{
	e->cameraX = 2 * (double)e->x / (double)e->w - 1;
	e->rayPosX = e->posX;
	e->rayPosY = e->posY;
	e->rayDirX = e->dirX + e->planeX * e->cameraX;
	e->rayDirY = e->dirY + e->planeY * e->cameraX;
}

void		ft_ray(t_aff *e)
{
	e->x = 0;
	while (e->x < e->w)
	{
		ft_initray(e);
		ray_calc(e);
		wall_detection(e);
		you_shall_not_past(e);
		draw_line(e);
		colors(e);
		e->x++;
	}
}

char		**ft_parse(char *str)
{
	int		fd;
	int		ret;
	char	*buff;
	char	**map;

	fd = open(str, O_RDONLY);
	buff = (char *)malloc(sizeof(char) * BUFF_SIZE2 + 1);
	ret = read(fd, buff, BUFF_SIZE2);
	buff[ret] = '\0';
	map = ft_strsplit(buff, '\n');
	return (map);
}

int			main(int ac, char **av)
{
	t_aff		*e;

	if (ac != 2)
	{
		ft_putstr("Missing parameter map\n");
		exit(0);
	}
	e = (t_aff *)malloc(sizeof(t_aff));
	struct_init(e);
	e->map = ft_parse(av[1]);
	mlx_expose_hook(e->win, expose_hook, e);
	mlx_hook(e->win, 2, 3, keyboard, e);
	mlx_loop(e->mlx);
	return (0);
}
