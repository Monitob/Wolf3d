/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/28 15:06:06 by gtandeo           #+#    #+#             */
/*   Updated: 2013/11/29 14:39:44 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

char	*ft_strtrim(const char *s)
{
	char	*temp;
	char	*temp2 = 0;

	temp = malloc(sizeof(char));
	while (*s == ' ' || *s == '\n' || *s == '\t')
	{
		s++;
	}
	while (*s != ' ' && *s != '\n' && *s != '\t' && *s != '\0')
	{
		ft_strcat(temp, s);
		s++;
		while (*s == ' ' || *s == '\n' || *s == '\t')
		{
			ft_strcpy(temp2, s);
			if (*s != ' ' && *s != '\n' && *s != '\t' && *s != '\0')
				ft_strcat (temp, temp2);
			if (*s == '\0')
				return (temp);
			s++;
		}
	}
	return (temp);
}
