/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/23 16:54:33 by gtandeo           #+#    #+#             */
/*   Updated: 2013/12/01 22:58:36 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

char	*ft_strrchr(const char *s, int c)
{
	char	*str;

	str = 0;
	if (*s == (char)c)
	{
		str = (char *)s;
	}
	while (*s != '\0')
	{
		if (*s == c)
		{
			str = (char *)s;
		}
		s++;
	}
	if (c == '\0')
	{
		str = (char *)s;
	}
	return (str);
}
