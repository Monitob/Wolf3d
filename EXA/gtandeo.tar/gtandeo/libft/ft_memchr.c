/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/23 14:32:59 by gtandeo           #+#    #+#             */
/*   Updated: 2013/11/27 21:28:03 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

void	*ft_memchr(const void *s, int c, size_t n)
{
	unsigned char *chaine;

	chaine = (unsigned char *)s;
	while (n-- != 0)
	{
		if (*chaine != (unsigned char)c)
		{
			chaine++;
		}
		else
		{
			return (chaine);
		}
	}
	return (NULL);
}
