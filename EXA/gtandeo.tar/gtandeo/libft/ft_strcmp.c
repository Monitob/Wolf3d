/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/22 08:47:31 by gtandeo           #+#    #+#             */
/*   Updated: 2013/11/27 21:38:15 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

int		ft_strcmp(const char *dest, const char *src)
{
	int		i;

	i = 0;
	while (dest[i] == src[i] && dest[i] != '\0')
	{
		i++;
	}
	return (dest[i] - src[i]);
}

