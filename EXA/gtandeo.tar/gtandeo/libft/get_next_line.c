/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/07 13:05:10 by gtandeo           #+#    #+#             */
/*   Updated: 2013/12/10 12:57:35 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

static int		buftostr(char buff[BUFF_SIZE], int *index, char **temp)
{
	int		i;
	char	*temp2;

	i = 0;
	temp2 = ft_strnew(BUFF_SIZE);
	while (temp2 && *index < BUFF_SIZE && buff[(*index % BUFF_SIZE)] != '\n'
		&& buff[*index])
	{
		temp2[i] = buff[(*index % BUFF_SIZE)];
		*index = *index + 1;
		i++;
	}
	*temp = ft_strjoin(*temp, temp2);
	if (buff[*index] == '\n')
	{
		*index = (*index + 1) % BUFF_SIZE;
		return (1);
	}
	else if (buff[(*index % BUFF_SIZE)] == '\0')
	{
		*index = (*index + 1) % BUFF_SIZE;
		return (0);
	}
	*index = (*index) % BUFF_SIZE;
	return (-1);
}

int				get_next_line(const int fd, char **line)
{
	static char		buff[BUFF_SIZE];
	static int		index = 0;
	int				i;
	int				ret;
	char			*temp;

	i = 0;
	ret = -1;
	temp = ft_strnew(BUFF_SIZE);
	if (temp && index && BUFF_SIZE > 1)
		ret = buftostr(buff, &index, &temp);
	while (temp && ret < 0)
	{
		ft_bzero(buff, BUFF_SIZE);
		ret = read(fd, buff, BUFF_SIZE);
		if (ret > 0)
			ret = buftostr(buff, &index, &temp);
		else if (ret == -1)
			return (-1);
	}
	*line = temp;
	return (ret);
}
