/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/23 21:53:05 by gtandeo           #+#    #+#             */
/*   Updated: 2013/11/30 19:00:07 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

char	*ft_strdup(const char *s)
{
	size_t	len;
	char	*ret;

	if (s != 0)
	{
		len = ft_strlen(s) + 1;
		ret = malloc(len);

		if (ret != 0)
		{
			ft_memcpy(ret, s, len);
		}
		else
		{
			ret = NULL;
		}
	}
	else
	{
		ret = NULL;
	}
	return (ret);
}
