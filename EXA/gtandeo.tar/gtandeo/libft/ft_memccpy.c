/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/23 09:09:54 by gtandeo           #+#    #+#             */
/*   Updated: 2013/11/27 21:27:48 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

void	*ft_memccpy(void *dest, const void *src, int c, size_t n)
{
	char	*s1;
	const char	*s2;
	char	temp;

	s1 = dest;
	s2 = src;
	while (n-- != 0)
	{
		temp = *s2++;
		*s1++ = temp;
		if (temp == (char)c)
		{
			return (s1);
		}
	}
	return (NULL);
}
