/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/28 11:57:26 by gtandeo           #+#    #+#             */
/*   Updated: 2013/12/08 19:01:50 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

char	*ft_strjoin(const char *s1, const char *s2)
{
	size_t	len;
	char	*tmp;

	len = 0;
	tmp = 0;
	if (s1 && s2)
	{
		len = (ft_strlen(s1) + ft_strlen(s2) + 1);
		tmp = (char*)malloc(len * sizeof(char));
		if (tmp)
		{
			ft_bzero(tmp, len);
			ft_strcat(tmp, s1);
			ft_strcat(tmp, s2);
		}
	}
	return (tmp);
}
