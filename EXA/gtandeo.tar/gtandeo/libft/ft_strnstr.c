/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/24 20:15:31 by gtandeo           #+#    #+#             */
/*   Updated: 2013/11/30 18:26:46 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

char	*ft_strnstr(const char *s1, const char *s2, size_t n)
{
	size_t	i;
	size_t	j;
	size_t	ptr;

	i = 0;
	j = 0;
	ptr = 0;
	while (s1[i] != '\0' && i < n)
	{
		if (s1[i] == s2[j])
		{
			if (j == 0)
				ptr = i;
			j++;
		}
		else
		{
			j = 0;
		}
		i++;
		if (s2[j] == '\0')
			return ((char *)(s1 + ptr));
	}
	return (0);
}
