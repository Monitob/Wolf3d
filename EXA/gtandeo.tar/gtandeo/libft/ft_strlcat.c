/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/24 20:13:31 by gtandeo           #+#    #+#             */
/*   Updated: 2013/12/01 18:10:57 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

size_t		ft_strlcat(char *dest, const char *src, size_t dsize)
{
	char	*d = dest;
	const char	*s = src;
	size_t	n = dsize;
	size_t	t;

	while (n-- != 0 && *d != '\0')
	{
		d++;
	}
	t = d - dest;
	n = dsize - t;
	if (n == 0)
		return (t + ft_strlen(s));
	while (*s != '\0')
	{
		if (n != 1)
		{
			*d++ = *s;
			n--;
		}
		s++;
	}
	*d = '\0';
	return (t + (s - src));
}
