/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnequ.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/28 11:19:48 by gtandeo           #+#    #+#             */
/*   Updated: 2013/11/28 11:26:09 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

int		ft_strnequ(const char *s1, const char *s2, size_t n)
{
	ft_strncmp(s1, s2, n);
	if (s1 == s2)
	{
		return (1);
	}
	return (0);
}
