/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsub.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/05 11:51:49 by gtandeo           #+#    #+#             */
/*   Updated: 2013/12/05 11:55:40 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

char	*ft_strsub(const char *s, unsigned int start, size_t len)
{
	char	*fresh_cpy;
	size_t	i;

	fresh_cpy = (char *)malloc((len + 1) * sizeof(char));
	i = 0;
	if (fresh_cpy && (len <= ft_strlen(s)))
	{
		while (i < len)
		{
			fresh_cpy[i] = s[start];
			start++;
			i++;
		}
		fresh_cpy[i] = '\0';
	}
	return (fresh_cpy);
}
