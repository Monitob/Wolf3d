/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/23 07:02:12 by gtandeo           #+#    #+#             */
/*   Updated: 2013/11/30 18:28:18 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

void	*ft_memset(void *s, int c, size_t n)
{
	size_t	count;
	unsigned char	*temp;

	count = 0;
	temp = (unsigned char *)s;
	while (count < n)
	{
		temp[count] = c;
		count++;
	}
	return (s);
}
