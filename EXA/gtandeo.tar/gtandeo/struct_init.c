/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   struct_init.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/17 05:28:43 by gtandeo           #+#    #+#             */
/*   Updated: 2014/01/22 16:38:23 by jbernabe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf.h"

void		struct_init(t_aff *e)
{
	env_init(e);
	player_init(e);
	ray_calc_init(e);
}

void		env_init(t_aff *e)
{
	e->w = 1000;
	e->h = 700;
	e->mlx = mlx_init();
	e->win = mlx_new_window(e->mlx, e->w, e->h, "Wolf3D");
	e->img = mlx_new_image(e->mlx, e->w, e->h);
	e->str = mlx_get_data_addr(e->img, &(e->bpp), &(e->s_line), &(e->endian));
}

void		player_init(t_aff *e)
{
	e->posX = 11;
	e->posY = 19;
}

void		ray_calc_init(t_aff *e)
{
	e->mapX = (int)e->rayPosX;
	e->mapY = (int)e->rayPosY;
	e->dirX = -1;
	e->dirY = 0;
	e->planeX = 0;
	e->planeY = 0.66;
	e->moveSpeed = 0.3;
	e->rotSpeed = 0.1;
}
