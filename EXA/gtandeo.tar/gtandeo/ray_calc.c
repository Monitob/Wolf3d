/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ray_calc.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/16 23:13:29 by gtandeo           #+#    #+#             */
/*   Updated: 2014/01/16 23:13:30 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf.h"

void		ray_calc(t_aff *e)
{
	e->mapX = (int)e->rayPosX;
	e->mapY = (int)e->rayPosY;
	e->dist2MurX = sqrt(1 + pow(e->rayDirY, 2) / pow(e->rayDirX, 2));
	e->dist2MurY = sqrt(1 + pow(e->rayDirX, 2) / pow(e->rayDirY, 2));
	e->touche = 0;
}

void		draw_line(t_aff *e)
{
	if (e->wall_type == 0)
		e->wall_dist = fabs((e->mapX - e->rayPosX +
			(1 - e->etapeX) / 2) / e->rayDirX);
	else
		e->wall_dist = fabs((e->mapY - e->rayPosY +
			(1 - e->etapeY) / 2) / e->rayDirY);
	e->hauteurMur = abs((int)(e->h / e->wall_dist));
	e->drawStart = -(e->hauteurMur) / 2 + e->h / 2;
	if (e->drawStart < 0)
		e->drawStart = 0;
	e->drawEnd = e->hauteurMur / 2 + e->h / 2;
	if (e->drawEnd >= e->h)
		e->drawEnd = e->h - 1;
}
