/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   deplacements.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/16 23:39:17 by gtandeo           #+#    #+#             */
/*   Updated: 2014/01/16 23:39:18 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf.h"

int			keyboard(int keycode, t_aff *e)
{
	translate(keycode, e);
	rotate(keycode, e);
	if (keycode == 65307)
		exit(0);
	expose_hook(e);
	return (0);
}

void		translate(int keycode, t_aff *e)
{
	if (keycode == 65362)
	{
		if (e->map[(int)(e->posX + e->dirX * e->moveSpeed)]
					[(int)(e->posY)] == '0')
			e->posX += e->dirX * e->moveSpeed;
		if (e->map[(int)(e->posX)]
					[(int)(e->posY + e->dirY * e->moveSpeed)] == '0')
			e->posY += e->dirY * e->moveSpeed;
	}
	if (keycode == 65364)
	{
		if (e->map[(int)(e->posX - e->dirX * e->moveSpeed)]
					[(int)(e->posY)] == '0')
			e->posX -= e->dirX * e->moveSpeed;
		if (e->map[(int)(e->posX)]
					[(int)(e->posY - e->dirY * e->moveSpeed)] == '0')
			e->posY -= e->dirY * e->moveSpeed;
	}
}

void		rotate(int keycode, t_aff *e)
{
	double		oldDirX;
	double		oldPlaneX;

	if (keycode == 65363)
	{
		oldDirX = e->dirX;
		e->dirX = e->dirX * cos(-(e->rotSpeed)) - e->dirY * sin(-(e->rotSpeed));
		e->dirY = oldDirX * sin(-(e->rotSpeed)) + e->dirY * cos(-(e->rotSpeed));
		oldPlaneX = e->planeX;
		e->planeX = e->planeX * cos(-(e->rotSpeed)) -
					e->planeY * sin(-(e->rotSpeed));
		e->planeY = oldPlaneX * sin(-(e->rotSpeed)) +
					e->planeY * cos(-(e->rotSpeed));
	}
	if (keycode == 65361)
	{
		oldDirX = e->dirX;
		e->dirX = e->dirX * cos(e->rotSpeed) - e->dirY * sin(e->rotSpeed);
		e->dirY = oldDirX * sin(e->rotSpeed) + e->dirY * cos(e->rotSpeed);
		oldPlaneX = e->planeX;
		e->planeX = e->planeX * cos(e->rotSpeed) - e->planeY * sin(e->rotSpeed);
		e->planeY = oldPlaneX * sin(e->rotSpeed) + e->planeY * cos(e->rotSpeed);
	}
}
