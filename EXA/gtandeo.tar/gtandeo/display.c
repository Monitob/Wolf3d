/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gtandeo <gtandeo@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/16 23:58:20 by gtandeo           #+#    #+#             */
/*   Updated: 2014/01/16 23:58:21 by gtandeo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf.h"

void		draw(t_aff *e)
{
	int		in;

	while (e->drawStart < e->drawEnd)
	{
		in = ((e->s_line * e->drawStart) + ((e->bpp >> 3) * e->x));
		e->str[in] = e->color & 0xFF;
		e->str[in + 1] = (e->color & 0xFF00) >> 8;
		e->str[in + 2] = (e->color & 0xFF0000) >> 16;
		e->drawStart++;
	}
}

void		colors(t_aff *e)
{
	if (e->map[e->mapY][e->mapX] == '1')
		e->color = 0xFF0000;
	else if (e->map[e->mapY][e->mapX] == '2')
		e->color = 0xFF0000;
	else if (e->map[e->mapY][e->mapX] == '3')
		e->color = 0xDB900E;
	else if (e->map[e->mapY][e->mapX] == '4')
		e->color = 0xFF0000;
	else if (e->map[e->mapY][e->mapX] == '5')
		e->color = 0xFF0000;
	else
		e->color = 0xFF0000;
	if (e->wall_type == 1)
		e->color /= 2;
	draw(e);
}
