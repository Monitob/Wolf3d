/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_size.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tdieumeg <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/08/27 22:28:39 by tdieumeg          #+#    #+#             */
/*   Updated: 2013/12/20 14:02:08 by tdieumeg         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	"libft.h"

int			ft_list_size(t_list *begin_list)
{
	int		i;
	t_list	*list;

	i = 0;
	list = NULL;
	list = begin_list;
	if (list != NULL)
	{
		i = 1;
		while (list->next != NULL)
		{
			list = list->next;
			i++;
		}
	}
	return (i);
}

