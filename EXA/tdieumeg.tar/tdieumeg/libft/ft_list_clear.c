/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_clear.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tdieumeg <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/08/28 14:40:55 by tdieumeg          #+#    #+#             */
/*   Updated: 2013/12/07 14:04:15 by tdieumeg         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include		<stdlib.h>
#include		"libft.h"

void			ft_list_clear(t_list **begin_list)
{
	t_list		*current;

	while (*begin_list != NULL)
	{
		current = *begin_list;
		*begin_list = current->next;
		free(current);
	}
	free(*begin_list);
	*begin_list = NULL;
}

