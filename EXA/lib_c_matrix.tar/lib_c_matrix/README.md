lib_c_matrix First Release = v.1.0.0 (14th january of 2014) by Thomas LE MIGNAN (from 42 school - Paris)
============================================================

Time and Space Equations (8) : 

**	Absolute this in a tri-dimensional matrix !
**	Vectorial movement in a tridimensional matrix !
**	Vector and Scalar product !
**	Plan use in a tridimensional matrix !

---------------------------------------------------------

French :

Note de l'auteur : Thomas LE MIGNAN

Tous les fichiers présents sont distribués sous Licence Creative Commons 0  : Public Domain Dedication.

N'oubliez pas la Terre. N'oubliez pas l'Humanité.


---------------------------------------------------------

English/US :

Author's Note: Thomas LE Mignan

All files are distributed under Creative Commons License 0: Public Domain Dedication.

Do not forget the Earth. Do not forget Mankind.

---------------------------------------------------------
lib_c_matrix Matrix Vectorial Equations or Algorithms implemented in a C Library
(CREATIVE COMMONS 0 - Public Domain Dedication / by Thomas LE MIGNAN)
---------------------------------------------------------
