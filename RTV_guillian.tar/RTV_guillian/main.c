/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/03 12:08:25 by glavanan          #+#    #+#             */
/*   Updated: 2014/02/15 14:01:16 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

void	ft_setimg(t_cal *cal)
{
	int		bpp;
	int		size;
	int		endian;

	size = endian = bpp = 0;
	cal->img = mlx_new_image(cal->mlx, WD_H, WD_W);
	cal->pix = mlx_get_data_addr(cal->img, &bpp, &size, &endian);
}

int		main(int argc, char **argv)
{
	t_cal		cal;
	t_obj		obj;
	t_obj		*tmp;

	if (!(ft_select_env(argc, argv, &cal, &obj)))
			return (0);
	tmp = &obj;
/*	while (tmp->next != NULL)
	{
		sleep(1);
		ft_putstr("\n");
		ft_putnbr(tmp->pos);
		tmp = tmp->next;
	}*/
	cal.mlx = mlx_init();
	cal.wdw = mlx_new_window(cal.mlx, WD_H, WD_W, "RTV1 IS THE BEST");
	ft_setimg(&cal);
	ft_draw(&cal, &obj);
	cal.loop = mlx_key_hook(cal.wdw, &ft_key_hook, &cal);
	cal.loop = mlx_expose_hook(cal.wdw, &ft_expose_hook, &cal);
	cal.loop = mlx_loop(cal.mlx);
	(void)argc;
	(void)argv;
	return (0);
}
