/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ini.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/16 14:43:24 by glavanan          #+#    #+#             */
/*   Updated: 2014/02/16 14:51:59 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

void		ft_calc_ray(t_cal *cal, int x, int y)
{
	cal->cam->rayx = (cal->cam->upx - cal->cam->camx) + cal->cam->rivx
		* cal->cam->wv / WD_H * x - cal->cam->upvx * cal->cam->hv / WD_W * y;
	cal->cam->rayy = (cal->cam->upy - cal->cam->camy) + cal->cam->rivy
		* cal->cam->wv / WD_H * x - cal->cam->upvy * cal->cam->hv / WD_W * y;
	cal->cam->rayz = (cal->cam->upz - cal->cam->camz) + cal->cam->rivz
		* cal->cam->wv / WD_H * x - cal->cam->upvz * cal->cam->hv / WD_W * y;
}

void		ft_plann(t_cal *cal)
{
	cal->cam->upx = cal->cam->camx + ((cal->cam->dp * cal->cam->vecdx)
			+ (cal->cam->hv / 2) * cal->cam->upvx) - ((cal->cam->wv / 2)
			* cal->cam->rivx);
	cal->cam->upy = cal->cam->camy + ((cal->cam->dp * cal->cam->vecdy)
			+ (cal->cam->hv / 2) * cal->cam->upvy) - (cal->cam->wv / 2)
		* cal->cam->rivy;
	cal->cam->upz = cal->cam->camz + ((cal->cam->dp * cal->cam->vecdz)
			+ (cal->cam->hv / 2) * cal->cam->upvz) - (cal->cam->wv / 2)
		* cal->cam->rivz;
}

void		ft_plan(t_cal *cal)
{
	double		longvec;

	cal->cam->vecdx = ((double)cal->cam->dirx - (double)cal->cam->camx);
	cal->cam->vecdy = ((double)cal->cam->diry - (double)cal->cam->camy);
	cal->cam->vecdz = ((double)cal->cam->dirz - (double)cal->cam->camz);
	longvec = sqrt(ft_car(cal->cam->vecdx) + ft_car(cal->cam->vecdy)
			+ ft_car(cal->cam->vecdz));
	cal->cam->vecdx = cal->cam->vecdx / longvec;
	cal->cam->vecdy = cal->cam->vecdy / longvec;
	cal->cam->vecdz = cal->cam->vecdz / longvec;
	cal->cam->upvx = 0;
	cal->cam->upvy = cal->cam->vecdz;
	cal->cam->upvz = -cal->cam->vecdy;
	cal->cam->rivx = (cal->cam->vecdy * cal->cam->upvz)
		- (cal->cam->vecdz * cal->cam->upvy);
	cal->cam->rivy = (cal->cam->vecdz * cal->cam->upvx)
		- (cal->cam->vecdx * cal->cam->upvz);
	cal->cam->rivz = (cal->cam->vecdx * cal->cam->upvy)
		- (cal->cam->vecdy * cal->cam->upvx);
	ft_plann(cal);
}
void		ft_ini(t_cal *cal, t_obj *obj)
{
	cal->cam = (t_cam *)malloc(sizeof(t_cam));
	cal->vp = (t_vp *)malloc(sizeof(t_vp));
	cal->sp = (t_sp *)malloc(sizeof(t_sp));
	cal->col = (t_col *)malloc(sizeof(t_col));
	cal->nu = 0;
	cal->cam->camx = obj->posx;
	cal->cam->camy = obj->posy;
	cal->cam->camz = obj->posz;
	cal->cam->fov = -((WD_H / 2) / (tan(15)));
	obj = obj->next;
	cal->cam->dirx = cal->cam->camx + obj->posx;
	cal->cam->diry = cal->cam->camy + obj->posy;
	cal->cam->dirz = cal->cam->camz + obj->posz;
	cal->cam->dp = 1.0;
	cal->cam->hv = 0.35;
	cal->cam->wv = 0.5;
	obj = obj->next;
	cal->sp->posx = obj->posx;
	cal->sp->posy = obj->posy;
	cal->sp->posz = obj->posz;
	ft_plan(cal);
}
