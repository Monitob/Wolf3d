/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rtv1.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/03 12:09:36 by glavanan          #+#    #+#             */
/*   Updated: 2014/02/16 15:11:38 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RTV1_H
# define RTV1_H

# define WD_H 640
# define WD_W 480
# define DV 1.0
# define HV 0.5
# define WV 0.35
# define POSZ 400
# include <mlx.h>
# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# include <math.h>
# include "./libft/libft.h"


typedef struct		s_obj
{
	int				pos;
	int				type;
	double			size;
	int				posx;
	int				posy;
	int				posz;
	int				col1;
	int				col2;
	int				col3;
	double			det;
	struct s_obj	*next;
	void			*prev;
}					t_obj;

typedef struct		s_col
{
	int				col1;
	int				col2;
	int				col3;
	int				colr1;
	int				colr2;
	int				colr3;
	int				colb1;
	int				colb2;
	int				colb3;
	int				colj1;
	int				colj2;
	int				colj3;
	int				colv1;
	int				colv2;
	int				colv3;
}					t_col;

typedef struct		s_cal
{
	void			*mlx;
	void			*wdw;
	void			*img;
	char			*pix;
	double			detmax;
	int				nu;
	int				loop;
	struct s_cam	*cam;
	struct s_vp		*vp;
	struct s_obj	*obj;
	struct s_col	*col;
	struct s_sp		*sp;
}					t_cal;

typedef struct		s_vp
{
	double			vpx;
	double			vpy;
	double			vpz;
}					t_vp;

typedef struct		s_cam
{
	double			camx;
	double			camy;
	double			camz;
	double			fov;
	double			dirx;
	double			diry;
	double			dirz;
	double			rayx;
	double			rayy;
	double			rayz;
	double			vecdx;
	double			vecdy;
	double			vecdz;
	double			upvx;
	double			upvy;
	double			upvz;
	double			rivx;
	double			rivy;
	double			rivz;
	double			dp;
	double			hv;
	double			wv;
	double			upx;
	double			upy;
	double			upz;
}					t_cam;

typedef struct		s_sp
{
	double			posx;
	double			posy;
	double			posz;
}					t_sp;


/*
** sha.c
*/

void		ft_initsha(t_cal *sha, t_cal *cal);
void		ft_shadow(t_cal *cal, t_obj *obj);
double		ft_car(double nb);
int			ft_put_p(t_cal *cal, double x, double y, t_obj *obj);


/*
** ini.c
*/

void		ft_calc_ray(t_cal *cal, int x, int y);
void		ft_plann(t_cal *cal);
void		ft_plan(t_cal *cal);
void		ft_ini(t_cal *cal, t_obj *obj);

/*
** pla.c
*/

void		ft_cal_pl(double vec[3], double ve2[3], t_cal *cal, t_obj *obj);
void		ft_cal_lum_pl(t_cal *cal, t_obj *obj);
double		ft_put_pl(t_cal *cal, t_obj *obj);

/*
** con.c
*/

void		ft_cal_co(double vec[3], double ve2[3], t_cal *cal, t_obj *obj);
void		ft_cal_lum_co(t_cal *cal, t_obj *obj);
double		ft_put_co(t_cal *cal, t_obj *obj);

/*
** sph.c
*/

double		ft_put_sp(t_cal *cal, t_obj *obj);
void		ft_cal_as(double vec[3], double ve2[3], t_cal *cal, t_obj *obj);
void		ft_cal_lum_sp(t_cal *cal, t_obj *obj);

/*
** cyl.c
*/

double		ft_put_cy(t_cal *cal, t_obj *obj);
void		ft_cal_cy(double vec[3], double ve2[3], t_cal *cal, t_obj *obj);
void		ft_cal_lum_cy(t_cal *cal, t_obj *obj);

/*
** draw.c
*/

double		ft_car(double nb);
void		ft_ini(t_cal *cal, t_obj *obj);
void		ft_draw(t_cal *cal, t_obj *obj);
double		ft_put_sphere(t_cal *cal, int sp[4]);
int			ft_put_p(t_cal *cal, double x, double y, t_obj *obj);

/*
** ft_hook.c
*/

int		ft_expose_hook(t_cal *cal);
int		ft_key_hook(int keycode, t_cal *cal);

/*
** ft_file_param.c
*/


int		ft_file_param_next2(t_obj *obj, char *str, int ret, char *nbr);
int		ft_file_param_next(t_obj *obj, char *str, int ret, char *nbr);

/*
** ft_env.c
*/

int		ft_file_param(t_obj *obj, char *str, int ret);
int		ft_init_obj(t_obj *obj, char *str, int ret, t_obj *tmp);
int		ft_file(t_obj *obj, char *str, int ret);
int		ft_read_file(int fd, t_obj *obj);
int		ft_select_env(int argc, char **argv, t_cal *cal, t_obj *obj);

#endif /* !RTV1_H */
