/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/04 13:30:54 by glavanan          #+#    #+#             */
/*   Updated: 2014/02/16 19:39:16 by jbernabe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

void	ft_place_objn(t_cal *cal, t_obj *obj)
{
	if (obj->type == 5)
	{
		if ((obj->det = ft_put_cy(cal, obj)) > 0.0001)
		{
			if (obj->det > cal->detmax && cal->detmax >= 0.0001);
			else
			{
				cal->nu = obj->pos;
				cal->detmax = obj->det;
			}
		}
	}
	else if (obj->type == 6)
	{
		if ((obj->det = ft_put_co(cal, obj)) > 0.0001)
		{
			if (obj->det > cal->detmax && cal->detmax >= 0.0001);
			else
			{
				cal->nu = obj->pos;
				cal->detmax = obj->det;
			}
		}
	}
}

void	ft_put_color(t_cal *cal, t_obj *obj, int x, int y)
{
	if (cal->nu != 0)
	{
		while (obj->pos != cal->nu)
		{
			obj = obj->next;

		}
		if (obj->type == 3)
			ft_cal_lum_sp(cal, obj);
		else if (obj->type == 4)
			ft_cal_lum_pl(cal, obj);
		else if (obj->type == 5)
			ft_cal_lum_cy(cal, obj);
		else if (obj->type == 6)
			ft_cal_lum_co(cal, obj);
	}
	if (cal->detmax > 0)
		ft_shadow(cal, obj);
	ft_put_p(cal, x, y, obj);
}

void	ft_place_obj(t_cal *cal, t_obj *obj)
{
	if (obj->type == 3)
	{
		if ((obj->det = ft_put_sp(cal, obj)) > 0.0001)
		{
			if (obj->det > cal->detmax && cal->detmax >= 0.0001);
			else
			{
				cal->nu = obj->pos;
				cal->detmax = obj->det;
			}
		}
	}
	else if (obj->type == 4)
	{
		if ((obj->det = ft_put_pl(cal, obj)) > 0.0001)
		{
			if (obj->det > cal->detmax && cal->detmax >= 0.0001);
			else
			{
				cal->nu = obj->pos;
				cal->detmax = obj->det;
			}
		}
	}
	ft_place_objn(cal, obj);
}

void	ft_put_obj(t_cal *cal, t_obj *obj, int x, int y)
{
	obj = obj->next;
	cal->detmax = 0;
	cal->nu = 0;
	ft_calc_ray(cal, x, y);
	cal->col->col1 = 0x00;
	cal->col->col2 = 0x00;
	cal->col->col3 = 0x00;
	while (obj->pos != 0)
	{
		if (obj->type > 2)
			ft_place_obj(cal, obj);
		obj = obj->next;
	}
	ft_put_color(cal, obj, x, y);
}

void	ft_draw(t_cal *cal, t_obj *obj)
{
	int			x;
	int			y;
	int			z;

	ft_ini(cal, obj);
	z = cal->cam->fov;
	x = 0;
	while (x < WD_H)
	{
		y = 0;
		while (y < WD_W)
		{
			ft_put_obj(cal, obj, x, y);
			y++;
		}
	x++;
	}
	free(cal->sp);
}
