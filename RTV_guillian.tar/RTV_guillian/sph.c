/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sph.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/16 11:50:57 by glavanan          #+#    #+#             */
/*   Updated: 2014/02/16 11:56:45 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

double		ft_put_sp(t_cal *cal, t_obj *obj)
{
	double	tmp[5];

	tmp[0] = ((cal->cam->rayx * cal->cam->rayx) + (cal->cam->rayy
				* cal->cam->rayy) + (cal->cam->rayz * cal->cam->rayz));
	tmp[1] = 2 * (((cal->cam->camx - obj->posx) * cal->cam->rayx)
			+ ((cal->cam->camy - obj->posy) * cal->cam->rayy)
			+ ((cal->cam->camz - obj->posz) * cal->cam->rayz));
	tmp[2] = (((cal->cam->camx - obj->posx) * (cal->cam->camx - obj->posx))
			+ ((cal->cam->camy - obj->posy)
				* (cal->cam->camy - obj->posy)) + ((cal->cam->camz - obj->posz)
				*(cal->cam->camz - obj->posz))) - ft_car(obj->size);
	tmp[3] = tmp[1] * tmp[1] - (4 * tmp[0] * tmp[2]);
	tmp[4] = (-tmp[1] - sqrt(tmp[3])) / (2 * tmp[0]);
	return (tmp[4]);
}

void		ft_cal_as(double vec[3], double ve2[3], t_cal *cal, t_obj *obj)
{
	double	indice;

	indice = (vec[0] * ve2[0]) + (vec[1] * ve2[1]) + (vec[2] * ve2[2]);
	if (cos(indice) >= 0)
	{
		cal->col->col1 = obj->col1 * (-cos(indice) + 0.25);
		cal->col->col2 = obj->col2 * (-cos(indice) + 0.25);
		cal->col->col3 = obj->col3 * (-cos(indice) + 0.25);
	}
	else
	{
		cal->col->col1 = 0x00;
		cal->col->col2 = 0x00;
		cal->col->col3 = 0x00;
	}
}

void		ft_cal_lum_sp(t_cal *cal, t_obj *obj)
{
	double		pos[3];
	double		vec[3];
	double		ve2[3];
	double		norm;

	pos[0] = cal->cam->camx + cal->cam->rayx * obj->det;
	pos[1] = cal->cam->camy + cal->cam->rayy * obj->det;
	pos[2] = cal->cam->camz + cal->cam->rayz * obj->det;
	vec[0] = pos[0] - cal->sp->posx;
	vec[1] = pos[1] - cal->sp->posy;
	vec[2] = pos[2] - POSZ;
	norm = sqrt(ft_car(vec[0]) + ft_car(vec[1]) + ft_car(vec[2]));
	vec[0] = vec[0] / norm;
	vec[1] = vec[1] / norm;
	vec[2] = vec[2] / norm;
	ve2[0] = pos[0] - obj->posx;
	ve2[1] = pos[1] - obj->posy;
	ve2[2] = pos[2] - obj->posz;
	norm = sqrt(ft_car(ve2[0]) + ft_car(ve2[1]) + ft_car(ve2[2]));
	ve2[0] = ve2[0] / norm;
	ve2[1] = ve2[1] / norm;
	ve2[2] = ve2[2] / norm;
	ft_cal_as(ve2, vec, cal, obj);
}
