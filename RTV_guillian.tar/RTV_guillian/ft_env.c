/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_env.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/03 12:45:20 by glavanan          #+#    #+#             */
/*   Updated: 2014/02/16 15:12:02 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

int		ft_file_param(t_obj *obj, char *str, int ret)
{
	char	*nbr;
	int		i;

	i = 0;
	ret = ret - 1;
	nbr = (char *)malloc(sizeof(char) * ft_strlen(str));
	while (str[ret] != '\t')
	{
		nbr[i] = str[ret];
		ret = ret + 1;
		i++;
	}
	nbr[i] = '\0';
	obj->type = ft_atoi(nbr);
	ret = ret + 1 + (i = 0);
	while (str[ret] != '\t')
	{
		nbr[i] = str[ret];
		ret = ret + 1;
		i++;
	}
	nbr[i] = '\0';
	obj->size = ft_atoi(nbr);
	ret = ft_file_param_next(obj, str, ret, nbr);
	return (ret);
}

int		ft_init_obj(t_obj *obj, char *str, int ret, t_obj *tmp)
{
	ret = ft_file_param(obj, str, ret);
	tmp->next = obj;
	obj->prev = NULL;
	return (ret);
}

int		ft_file(t_obj *obj, char *str, int ret)
{
	ft_putstr("FILE\n");
	t_obj	*tmp;


	tmp = (t_obj *)malloc(sizeof(t_obj));
	ret++;
	if (obj->pos == -1)
	{
		ft_putstr("enytance\n");
		obj->pos = 0;
		ret = ft_init_obj(obj, str, ret, obj);
	}
	else
	{
		tmp->next = obj;
		while (obj->next->pos != 0)
			obj = obj->next;
		tmp->pos = obj->pos + 1;
		ft_init_obj(tmp, str, ret, obj);
	}
	return (ret);
}

int		ft_read_file(int fd, t_obj *obj)
{
	int		ret;
	char	buf[1025];
	char	*tmp;
	char	*str;

	str = (char *)malloc(sizeof(char) * 1);
	ret = 0;
	str[0] = '\0';
	while ((ret = read(fd, buf, 1024)) > 0)
	{
		buf[ret] = '\0';
		tmp = ft_strjoin(str, buf);
		free(str);
		str = tmp;
	}
	if (ret == - 1)
		return (0);
	ret = 0;
	ft_file(obj, str, ret);
	while (str[ret++])
	{
		if (str[ret] && str[ret] == '\n' && str[ret + 1] != '\0')
			ft_file(obj, str, ret + 1);
	}
	return (1);
}

int		ft_select_env(int argc, char **argv, t_cal *cal, t_obj *obj)
{
	int		fd;

	(void)cal;
	obj->pos = -1;
	if (argc == 1)
	{
		ft_putstr_fd("usage : ./rtv1 file\n", 2);
		return (0);
	}
	if (argc > 2)
	{
		ft_putstr("only : ");
		ft_putstr(argv[1]);
		ft_putstr(" will be open\n");
	}
	if ((fd = open(argv[1], O_RDONLY)) == -1)
	{
		ft_putstr("can't open file");
		return (0);
	}
	ft_putstr("selesct_env\n");
	ft_read_file(fd, obj);
	return (1);
}
