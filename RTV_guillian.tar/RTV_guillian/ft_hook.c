/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_hook.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/03 12:25:33 by glavanan          #+#    #+#             */
/*   Updated: 2014/02/03 12:35:54 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

int		ft_key_hook(int keycode, t_cal *cal)
{
	if (keycode == 65307)
		exit(0);
	(void)cal;
	return (0);
}

int		ft_expose_hook(t_cal *cal)
{
	int		i;

	i = 0;
	if (cal)
		mlx_put_image_to_window(cal->mlx, cal->wdw, cal->img, 0, 0);
	return (i);
}
