/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/21 09:08:47 by glavanan          #+#    #+#             */
/*   Updated: 2013/12/19 16:00:19 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>
#include <stdlib.h>

void	*ft_memmove(void *dest, const void *src, size_t n)
{
	unsigned char	*temp1;
	unsigned char	*temp2;
	unsigned char	*buffer;

	temp1 = dest;
	temp2 = (unsigned char *)src;
	buffer = (unsigned char *)malloc(sizeof(*buffer
			* (int)ft_strlen((char *)temp1)));
	if (buffer == NULL)
		return (NULL);
	buffer = ft_memcpy(buffer, temp2, n);
	temp1 = ft_memcpy(temp1, buffer, n);
	return (dest);
}

