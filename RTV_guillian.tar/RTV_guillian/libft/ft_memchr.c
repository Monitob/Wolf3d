/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 09:34:16 by glavanan          #+#    #+#             */
/*   Updated: 2013/12/01 22:55:50 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>

void	*ft_memchr(const void *s, int c, size_t n)
{
	int		i;

	i = 0;
	if (!s || !c || !n)
		return (0);
	while (*((char*)s + i) != c && i <= (int)n)
	{
		i++;
	}
	if (*((char *)s + i) == c)
		return ((void *)s + i);
	return (NULL);
}

