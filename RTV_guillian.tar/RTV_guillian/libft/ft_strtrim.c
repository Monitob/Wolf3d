/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/24 10:35:47 by glavanan          #+#    #+#             */
/*   Updated: 2013/12/01 23:11:22 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>
#include <stdlib.h>

char	*ft_strtrim(char const *s)
{
	int		i1;
	int		i2;
	char	*str;
	int		i;

	i = 0;
	i2 = (int)ft_strlen(s) - 1;
	i1 = 0;
	while (s[i2] == ' ' || s[i2] == '\n' || s[i2] == '\t')
		i2--;
	while (s[i1] == ' ' || s[i1] == '\n' || s[i1] == '\t')
		i1++;
	str = (i1 > i2) ? (char *)malloc((1 * sizeof(char *)))
		: (char *)malloc(sizeof(str) * (i2 - i1 + 2));
	if (str == NULL)
		return (NULL);
	while (i1 <= i2)
	{
		str[i] = s[i1];
		i1++;
		i++;
	}
	str[i] = '\0';
	return (str);
}

