/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                        :+:      :+:    :+:  */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 09:34:16 by glavanan          #+#    #+#             */
/*   Updated: 2013/12/01 23:25:56 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>

char	*ft_strnstr(const char *s, const char *s2, size_t n)
{
	size_t		i;
	size_t		i2;

	i = 0;
	i2 = 0;
	if (s == NULL || s2 == NULL)
		return (NULL);
	if (*s2 == '\0')
		return ((char *)s);
	while (s[i] != '\0' && n)
	{
		i2 = 0;
		while (s[i] == s2[i2] && ((s[i] != '\0') || (s2[i2] != '\0')) && n)
		{
			n--;
			i++;
			i2++;
		}
		if (s2[i2] == '\0')
			return ((char *)s + i - i2);
		n--;
		i = i - i2 + 1;
	}
	return (NULL);
}

