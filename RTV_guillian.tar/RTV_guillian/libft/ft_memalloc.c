/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memalloc.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/22 17:46:49 by glavanan          #+#    #+#             */
/*   Updated: 2013/12/01 23:36:25 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <string.h>

void	*ft_memalloc(size_t size)
{
	char	*d;
	int		i;

	i = 0;
	d = malloc(size);
	if (d == NULL)
		return (NULL);
	while (i <= (int)size)
	{
		d[i] = 0;
		i++;
	}
	return (d);
}

