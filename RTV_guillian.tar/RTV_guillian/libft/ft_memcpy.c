/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/21 09:08:47 by glavanan          #+#    #+#             */
/*   Updated: 2013/12/19 16:01:08 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <string.h>

void	*ft_memcpy(void *dest, const void *src, size_t n)
{
	int		i;

	i = 0;
	if (!dest || !src || !n)
		return (0);
	if (dest && src && n)
	{
		while (n > 0)
		{
			*((char*)dest + i) = *((char *)src + i);
			n--;
			i++;
		}
		return (dest);
	}
	return (0);
}

