/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 16:19:05 by glavanan          #+#    #+#             */
/*   Updated: 2013/12/01 23:23:47 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>

int		ft_memcmp(const void *s1, const void *s2, size_t n)
{
	int				i;
	char const		*p1;
	char const		*p2;

	p1 = (char *)s1;
	p2 = (char *)s2;
	i = 0;
	if (!s1 || !s2 || !n)
		return (0);
	while (n--)
	{
		if (p1[i] != p2[i])
		{
			return (p1[i] - p2[i]);
		}
		i++;
	}
		return (0);
}

