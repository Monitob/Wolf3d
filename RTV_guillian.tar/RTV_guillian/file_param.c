/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file_param.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/03 14:26:46 by glavanan          #+#    #+#             */
/*   Updated: 2014/02/15 14:00:25 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"



int		ft_file_param_next3(t_obj *obj, char *str, int ret, char *nbr)
{
	int		i;

	i = 0;
	ret = ret + 1;
	while (str[ret] != '\t')
	{
		nbr[i] = str[ret];
		ret = ret + 1;
		i++;
	}
	nbr[i] = '\0';
	obj->col2 = ft_atoi(nbr);
	ret = ret + 1 + (i = 0);
	while (str[ret] != '\n' && str[ret] != '\0')
	{
		nbr[i] = str[ret];
		ret = ret + 1;
		i++;
	}
	nbr[i] = '\0';
	obj->col3 = ft_atoi(nbr);
	return (ret);
}

int		ft_file_param_next2(t_obj *obj, char *str, int ret, char *nbr)
{
	int		i;

	i = 0;
	ret = ret + 1;
	while (str[ret] != '\t')
	{
		nbr[i] = str[ret];
		ret = ret + 1;
		i++;
	}
	nbr[i] = '\0';
	obj->posz = ft_atoi(nbr);
	ret = ret + 1 + (i = 0);
	while (str[ret] != '\t')
	{
		nbr[i] = str[ret];
		ret = ret + 1;
		i++;
	}
	nbr[i] = '\0';
	obj->col1 = ft_atoi(nbr);
	ft_file_param_next3(obj, str, ret, nbr);
	return (ret);
}

int		ft_file_param_next(t_obj *obj, char *str, int ret, char *nbr)
{
	int		i;
	i = 0;
	ret = ret + 1;
	while (str[ret] != '\t')
	{
		nbr[i] = str[ret];
		ret = ret + 1;
		i++;
	}
	nbr[i] = '\0';
	obj->posx = ft_atoi(nbr);
	ret = ret + 1 + (i = 0);
	while (str[ret] != '\t')
	{
		nbr[i] = str[ret];
		ret = ret + 1;
		i++;
	}
	nbr[i] = '\0';
	obj->posy = ft_atoi(nbr);
	ret = ft_file_param_next2(obj, str, ret, nbr);
	return (ret);
}
