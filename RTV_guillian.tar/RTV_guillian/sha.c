/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sha.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glavanan <glavanan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/16 14:53:04 by glavanan          #+#    #+#             */
/*   Updated: 2014/02/16 14:58:07 by glavanan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

void		ft_initsha(t_cal *sha, t_cal *cal)
{
	double		pos[3];
	double		lum[3];

	sha->cam = (t_cam *)malloc(sizeof(t_cam));
	pos[0] = cal->cam->camx + cal->cam->rayx * cal->detmax;
	pos[1] = cal->cam->camy + cal->cam->rayy * cal->detmax;
	pos[2] = cal->cam->camz + cal->cam->rayz * cal->detmax;
	lum[0] = pos[0] - cal->sp->posx;
	lum[1] = pos[1] - cal->sp->posy;
	lum[2] = pos[2] - POSZ;
	sha->cam->rayx = lum[0];
	sha->cam->rayy = lum[1];
	sha->cam->rayz = lum[2];
	sha->cam->camx = cal->sp->posx;
	sha->cam->camy = cal->sp->posy;
	sha->cam->camz = POSZ;
}

void		ft_shadow(t_cal *cal, t_obj *obj)
{
	t_cal		sha;
	double		i;

	ft_initsha(&sha, cal);
	while (obj->pos != 1)
		obj = obj->next;
	while (obj->pos != 0)
	{
		if (obj->type == 3 && (i = ft_put_sp(&sha, obj)) > 0.001 && i < 0.999)
			break ;
		if (obj->type == 4 && (i = ft_put_pl(&sha, obj)) > 0.001 && i < 0.999)
			break ;
		if (obj->type == 5 && (i = ft_put_cy(&sha, obj)) > 0.001 && i < 0.999)
			break ;
		if (obj->type == 6 && (i = ft_put_co(&sha, obj)) > 0.001 && i < 0.999)
			break ;
		else
			obj = obj->next;
	}
	if (obj->pos != 0)
		cal->col->col1 = (cal->col->col2 = cal->col->col3 = 0x30) * 1;
}

double		ft_car(double nb)
{
	return (nb * nb);
}

int			ft_put_p(t_cal *cal, double x, double y, t_obj *obj)
{
	int		i;

	(void)obj;
	i = y * WD_H * 4 + x * 4;
	cal->pix[i++] = cal->col->col1;
	cal->pix[i++] = cal->col->col2;
	cal->pix[i++] = cal->col->col3;
	return (0);
}
